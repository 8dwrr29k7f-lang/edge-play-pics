import {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
  ActivityType,
  EmbedBuilder
} from "discord.js";
import cron from "node-cron";
import { config, assertConfig } from "./config.js";
import { wireEmbed, limitsEmbed, scoresEmbed, helpEmbed } from "./embeds.js";
import { fetchMlbScores } from "./scores.js";
import { fetchMultiScores } from "./liveScores.js";
import { runScan } from "./scanner.js";
import {
  liveBestBetsEmbed,
  liveLocksEmbed,
  livePLEmbed,
  liveAllPicksEmbed
} from "./liveEmbeds.js";
import { refreshData } from "./liveApi.js";
import {
  categoryEmbed,
  bestOverallEmbed,
  allLocksEmbed,
  mediaAllEmbed
} from "./categoryEmbed.js";
import { categories } from "./data/desk.js";
import { lotdEmbed, liveCardEmbed, locksTodayEmbed } from "./lotdEmbed.js";
import { scanCashoutAlerts, hedgesEmbed } from "./cashout.js";
import { leanEmbed, holdEmbed, mediaFollowEmbed } from "./mediaFollow.js";
import {
  morningBundle,
  eveningBundle,
  runChangeAnnounce,
  initSnapshotIfEmpty
} from "./announce.js";
import { learnEmbed, enhanceReviewEmbed } from "./trackerLearn.js";
import { rollDailyCard, ensureTodayCard } from "./dailyRoll.js";
import {
  logPick,
  gradePick,
  ingestLivePicks,
  trackerSummaryEmbed,
  trackerReviewEmbed,
  trackerPendingEmbed
} from "./tracker.js";

assertConfig();

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
  partials: [Partials.Channel]
});

const SPORT_KEYS = Object.keys(categories);

async function postToPics(payloads) {
  if (!config.picsChannelId || !payloads?.length) return;
  try {
    const ch = await client.channels.fetch(config.picsChannelId);
    if (!ch || !ch.isTextBased()) return;
    for (const p of payloads) {
      await ch.send({ content: p.content, embeds: p.embeds || [] });
      await new Promise((r) => setTimeout(r, 600));
    }
  } catch (e) {
    console.error("auto-post:", e.message);
  }
}

async function pushLiveScores() {
  const mins = config.scanMinutes;
  try {
    const boards = await fetchMultiScores(["mlb", "nfl", "nba"]);
    const lines = [];
    let live = 0;
    let fin = 0;
    for (const b of boards) {
      if (b.error) {
        lines.push(`**${b.sport.toUpperCase()}** — feed error: ${b.error}`);
        continue;
      }
      live += b.liveCount || 0;
      fin += b.finalCount || 0;
      if (!b.lines?.length) {
        lines.push(`**${b.sport.toUpperCase()}** — no games on board`);
        continue;
      }
      lines.push(
        `**${b.sport.toUpperCase()}** (${b.liveCount} live / ${b.finalCount} final)`
      );
      lines.push(...b.lines.slice(0, 8));
    }
    const emb = new EmbedBuilder()
      .setColor(0x3498db)
      .setTitle("📡 LIVE SCORES · AUTO")
      .setDescription(lines.join("\n").slice(0, 4000) || "No games")
      .setFooter({
        text: `ESPN public · every ${mins}m · EDGE PLAY · 21+`
      })
      .setTimestamp();
    await postToPics([
      {
        content: `📡 **Live update** · ${live} in progress · ${fin} final`,
        embeds: [emb]
      }
    ]);
    console.log(`Posted live scores live=${live} final=${fin}`);
  } catch (e) {
    console.error("live scores:", e.message);
  }
}

async function pushOddsOrStatic() {
  try {
    const result = await refreshData();
    if (result?.picks) {
      try {
        ingestLivePicks(result);
      } catch {
        /* ignore */
      }
      const locks = (result.picks || []).filter(
        (p) => p.tier === "LOCK" || p.tier === "CAP"
      );
      if (locks.length) {
        await postToPics([
          {
            content: "🔒 **LIVE LOCKS & CAPS** (odds API)",
            embeds: [await liveLocksEmbed()]
          }
        ]);
      }
    }
  } catch (e) {
    console.error("odds refresh:", e.message);
  }
}

function armSchedules() {
  const mins = config.scanMinutes;
  console.log(`Live updates every ${mins}m · channel ${config.picsChannelId}`);

  setInterval(pushLiveScores, mins * 60 * 1000);
  setInterval(async () => {
    try {
      await ensureTodayCard();
      console.log("Live pick scan / daily card refresh OK");
    } catch (e) {
      console.error("daily scan", e.message);
    }
  }, mins * 60 * 1000);
  setInterval(pushOddsOrStatic, mins * 60 * 1000);
  setInterval(async () => {
    try {
      const alerts = await scanCashoutAlerts();
      if (alerts.length) {
        await postToPics(alerts);
        console.log("Cashout alerts:", alerts.length);
      }
    } catch (e) {
      console.error("cashout scan", e.message);
    }
  }, Math.max(5, mins) * 60 * 1000);

  setTimeout(async () => {
    try {
      await postToPics([
        {
          content:
            "👑 **EDGE PLAY PICS IS LIVE**\n" +
            "Lock of the Day · clear TAKE/PASS · hedges · cash-out watch\n" +
            "Hit `/lotd` · `/locks` · `/live` — let's cook."
        }
      ]);
    } catch (e) {
      console.error("boot hype", e.message);
    }
    await ensureTodayCard();
    await pushLiveScores();
    await pushOddsOrStatic();
    console.log("Boot live push done");
  }, 12000);

  // —— EVERY DAY automatic desk ——
  cron.schedule(
    "0 7 * * *",
    async () => {
      console.log("Morning desk auto");
      try {
        await rollDailyCard({ force: true });
        for (const payload of morningBundle()) {
          await postToPics([payload]);
          await new Promise((r) => setTimeout(r, 800));
        }
        await pushLiveScores();
      } catch (e) {
        console.error("morning", e.message);
      }
    },
    { timezone: "America/Chicago" }
  );

  // Midday refresh card
  cron.schedule(
    "0 12 * * *",
    async () => {
      try {
        await postToPics([
          {
            content: "🕛 **MIDDAY DESK CHECK** — card still live · `/live` `/locks`",
            embeds: [liveCardEmbed()]
          }
        ]);
        const ch = await runChangeAnnounce();
        if (ch.length) await postToPics(ch);
      } catch (e) {
        console.error("midday", e.message);
      }
    },
    { timezone: "America/Chicago" }
  );

  cron.schedule(
    "0 22 * * *",
    async () => {
      try {
        for (const payload of eveningBundle()) {
          await postToPics([payload]);
        }
        await postToPics([
          {
            content: "🌙 **NIGHT** — grade with `/grade` · KBO process overnight",
            embeds: [categoryEmbed("kbo")].filter(Boolean)
          }
        ]);
      } catch (e) {
        console.error("evening", e.message);
      }
    },
    { timezone: "America/Chicago" }
  );

  // Change detector every scan cycle (media / stats / tier moves)
  setInterval(async () => {
    try {
      const payloads = await runChangeAnnounce();
      if (payloads.length) {
        await postToPics(payloads);
        console.log("Announced card/media changes");
      }
    } catch (e) {
      console.error("announce", e.message);
    }
  }, mins * 60 * 1000);

  initSnapshotIfEmpty();
}


client.once(Events.ClientReady, (c) => {
  console.log(`👑 EDGE PLAY PICS online as ${c.user.tag}`);
  console.log("Desk armed · /lotd · /locks · /live · /hedge · /track");
  c.user.setActivity("👑 LOTD · /locks · /live", { type: ActivityType.Watching });
  // Rotate status lightly for hype without spam
  const statuses = [
    "👑 LOCK OF THE DAY · /lotd",
    "🔒 TAKE list · /locks",
    "📡 LIVE card · /live",
    "🛡️ Hedges · /hedge",
    "📊 Track · /track"
  ];
  let si = 0;
  setInterval(() => {
    si = (si + 1) % statuses.length;
    c.user.setActivity(statuses[si], { type: ActivityType.Watching }).catch(() => {});
  }, 12 * 60 * 1000);
  if (config.picsChannelId) armSchedules();
  else console.warn("No PICS_CHANNEL_ID — slash cmds work, auto-post off");
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  const name = interaction.commandName;

  try {
    if (SPORT_KEYS.includes(name)) {
      const emb = categoryEmbed(name);
      await interaction.reply({
        embeds: emb ? [emb] : undefined,
        content: emb ? undefined : "Unknown desk."
      });
      return;
    }

    if (name === "best") {
      await interaction.deferReply();
      await interaction.editReply({
        embeds: [lotdEmbed(), await liveBestBetsEmbed()]
      });
      return;
    }
    if (name === "locks") {
      await interaction.deferReply();
      await interaction.editReply({ embeds: [await liveLocksEmbed()] });
      return;
    }
    if (name === "picks" || name === "all") {
      await interaction.deferReply();
      await interaction.editReply({ embeds: [await liveAllPicksEmbed()] });
      return;
    }
    if (name === "pl" || name === "tracker") {
      await interaction.deferReply();
      await interaction.editReply({ embeds: [await livePLEmbed()] });
      return;
    }
    if (name === "updates") {
      await interaction.deferReply();
      const payloads = await runChangeAnnounce();
      if (payloads.length) {
        await postToPics(payloads);
        await interaction.editReply({ content: "📢 Posted desk updates to the channel.", embeds: payloads[0].embeds });
      } else {
        await interaction.editReply({ content: "✅ No pick/media changes since last snapshot. Card is stable." });
      }
      return;
    }
    if (name === "daily" || name === "roll") {
      await interaction.deferReply();
      const card = await rollDailyCard({ force: true });
      await postToPics([
        {
          content: `📅 **NEW DAILY CARD** · ${card.dateLabel} · ${card.picks.length} actions`,
          embeds: [liveCardEmbed(), lotdEmbed()]
        }
      ]);
      await interaction.editReply({
        content: `📅 Rolled **${card.dateKey}** — ${card.picks.length} picks · live ${card.liveCount || 0}. Posted to channel.`,
        embeds: [liveCardEmbed()]
      });
      return;
    }
    if (name === "lean") {
      await interaction.reply({ embeds: [leanEmbed()] });
      return;
    }
    if (name === "hold") {
      await interaction.reply({ embeds: [holdEmbed()] });
      return;
    }
    if (name === "media" || name === "follow") {
      await interaction.deferReply();
      await interaction.editReply({ embeds: [await mediaFollowEmbed()] });
      return;
    }
    if (name === "refresh") {
      await interaction.deferReply();
      const result = await refreshData();
      if (result) {
        try {
          ingestLivePicks(result);
        } catch {
          /* ignore */
        }
        await interaction.editReply({
          content: `📡 **Refreshed** — ${result.total_picks ?? "?"} picks`,
          embeds: [await liveBestBetsEmbed()]
        });
      } else {
        await interaction.editReply({
          content:
            "⚠️ Odds API offline — static desks OK. ESPN live still works via `/scores` + auto.",
          embeds: [bestOverallEmbed(), allLocksEmbed()]
        });
      }
      return;
    }
    if (name === "pics" || name === "wire") {
      await interaction.deferReply();
      await interaction.editReply({
        embeds: [wireEmbed(), await liveBestBetsEmbed()]
      });
      return;
    }
    if (name === "limits") {
      await interaction.reply({ embeds: [limitsEmbed()] });
      return;
    }
    if (name === "help") {
      await interaction.reply({ embeds: [helpEmbed()] });
      return;
    }
    if (name === "scores") {
      await interaction.deferReply();
      try {
        const boards = await fetchMultiScores(["mlb", "nfl", "nba"]);
        const lines = [];
        for (const b of boards) {
          lines.push(`**${b.sport.toUpperCase()}**`);
          if (b.error) lines.push(`Error: ${b.error}`);
          else lines.push(...(b.lines || []).slice(0, 10));
        }
        await interaction.editReply({
          embeds: [
            scoresEmbed(
              lines,
              `ESPN multi · ${new Date().toLocaleString("en-US", { timeZone: "America/Chicago" })} CT`
            )
          ]
        });
      } catch (e) {
        await interaction.editReply({
          embeds: [scoresEmbed([], e.message)]
        });
      }
      return;
    }
    if (name === "scan") {
      await interaction.deferReply();
      await pushLiveScores();
      const result = await refreshData();
      if (result?.picks) {
        try {
          ingestLivePicks(result);
        } catch {
          /* ignore */
        }
      }
      const embed = await liveBestBetsEmbed();
      await postToPics([
        {
          content: result
            ? "📡 **SCAN · scores + odds**"
            : "📡 **SCAN · scores (odds API offline)**",
          embeds: [embed]
        }
      ]);
      await interaction.editReply({
        content: result
          ? `📡 Scan OK — ${result.total_picks ?? 0} odds picks + ESPN posted.`
          : "📡 Scan OK — ESPN live posted; odds API offline.",
        embeds: [embed]
      });
      return;
    }
    if (name === "status") {
      await interaction.deferReply();
      try {
        const boards = await fetchMultiScores(["mlb"]);
        const b = boards[0] || {};
        const api = await refreshData();
        await interaction.editReply({
          content:
            `**Live status**\n` +
            `ESPN MLB: **${b.games?.length ?? 0}** games · live **${b.liveCount ?? 0}** · final **${b.finalCount ?? 0}**\n` +
            `Odds API: **${api ? "up" : "offline (static desks OK)"}**\n` +
            `Auto channel: **${config.picsChannelId ? "set" : "MISSING PICS_CHANNEL_ID"}**\n` +
            `Scan every **${config.scanMinutes}m**\n` +
            `Bot must stay running for auto updates.`
        });
      } catch (e) {
        await interaction.editReply({ content: "Status error: " + e.message });
      }
      return;
    }
    if (name === "track") {
      await interaction.reply({ embeds: [trackerSummaryEmbed()] });
      return;
    }
    if (name === "review") {
      await interaction.reply({ embeds: [enhanceReviewEmbed()] });
      return;
    }
    if (name === "learn") {
      await interaction.reply({ embeds: [learnEmbed()] });
      return;
    }
    if (name === "pending") {
      await interaction.reply({ embeds: [trackerPendingEmbed()] });
      return;
    }
    if (name === "logpick") {
      const row = logPick({
        sport: interaction.options.getString("sport"),
        selection: interaction.options.getString("selection"),
        odds: interaction.options.getNumber("odds"),
        units: interaction.options.getNumber("units"),
        label: interaction.options.getString("label") || "VALUE",
        market: interaction.options.getString("market") || "ml",
        betType: interaction.options.getString("market") || "ml",
        game: interaction.options.getString("game") || "",
        reasons: interaction.options.getString("reasons") || ""
      });
      await interaction.reply({
        content: `📝 Logged \`${row.id}\` · **${row.sport}** ${row.selection} ${row.odds > 0 ? "+" : ""}${row.odds} · ${row.units}u · ${row.label}`,
        ephemeral: true
      });
      return;
    }
    if (name === "grade") {
      const row = gradePick({
        result: interaction.options.getString("result"),
        id: interaction.options.getString("id") || undefined,
        selection: interaction.options.getString("selection") || undefined,
        closingOdds: interaction.options.getNumber("closing")
      });
      if (!row) {
        await interaction.reply({
          content: "No matching pending pick. Use `/pending` for ids.",
          ephemeral: true
        });
        return;
      }
      await interaction.reply({
        content: `✅ Graded \`${row.id}\` → **${row.result}** · P/L **${row.pl >= 0 ? "+" : ""}${row.pl?.toFixed?.(2) ?? row.pl}u**`,
        embeds: [trackerSummaryEmbed()]
      });
      return;
    }

    await interaction.reply({ content: "Try `/help`", ephemeral: true });
  } catch (e) {
    console.error(e);
    const msg = { content: "Desk hiccup — hit that command one more time.", ephemeral: true };
    if (interaction.deferred || interaction.replied)
      await interaction.followUp(msg).catch(() => {});
    else await interaction.reply(msg).catch(() => {});
  }
});

client.login(config.token);
