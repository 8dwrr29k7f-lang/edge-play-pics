/**
 * Daily automation + change announcements
 * - Morning card every day
 * - Evening recap
 * - Detect pick tier / media / price-guide changes → channel update
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { EmbedBuilder } from "discord.js";
import { liveCard, lockOfTheDay, premiumAlerts } from "./data/desk.js";
import { lotdEmbed, liveCardEmbed, locksTodayEmbed } from "./lotdEmbed.js";
import { leanEmbed, holdEmbed, mediaFollowEmbed } from "./mediaFollow.js";
import { fetchMediaFeed } from "./mediaFollow.js";
import { config } from "./config.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SNAP = path.join(__dirname, "data", "announce_snap.json");

function loadSnap() {
  try {
    return JSON.parse(fs.readFileSync(SNAP, "utf8"));
  } catch {
    return { picks: {}, media: "", lotd: "", ts: null };
  }
}

function saveSnap(s) {
  fs.mkdirSync(path.dirname(SNAP), { recursive: true });
  fs.writeFileSync(SNAP, JSON.stringify(s, null, 2));
}

function pickFingerprint(p) {
  return [p.tier, p.selection, p.price, p.units, p.why?.slice(0, 80)].join("|");
}

/** Compare live card to last snapshot → list of human change lines */
export function detectCardChanges() {
  const snap = loadSnap();
  const changes = [];
  const nextPicks = {};

  for (const p of liveCard.picks || []) {
    const key = `${p.sport}|${p.game}|${p.selection}`;
    const fp = pickFingerprint(p);
    nextPicks[key] = fp;
    const prev = snap.picks?.[key];
    if (!prev) {
      changes.push({
        type: "new",
        line: `🆕 **NEW** \`${p.tier}\` · **${p.selection}** (${p.sport})\n${p.price} · ${p.units}u\n_${p.why}_`
      });
      continue;
    }
    if (prev !== fp) {
      const prevTier = prev.split("|")[0];
      const up =
        (prevTier === "HOLD" || prevTier === "PASS" || prevTier === "LEAN") &&
        (p.tier === "LOCK" || p.tier === "CAP" || p.tier === "VALUE");
      const down =
        (prevTier === "LOCK" || prevTier === "CAP") &&
        (p.tier === "LEAN" || p.tier === "HOLD" || p.tier === "PASS");
      const emoji = up ? "⬆️" : down ? "⬇️" : "🔄";
      changes.push({
        type: down ? "downgrade" : up ? "upgrade" : "update",
        line:
          `${emoji} **${prevTier} → ${p.tier}** · **${p.selection}**\n` +
          `Price guide: ${p.price} · ${p.units}u\n_${p.why}_`
      });
    }
  }

  // Removed picks
  for (const key of Object.keys(snap.picks || {})) {
    if (!nextPicks[key]) {
      changes.push({
        type: "removed",
        line: `🗑️ **OFF THE CARD** · ${key.replace(/\|/g, " · ")}`
      });
    }
  }

  const lotdKey = `${lockOfTheDay?.pick}|${lockOfTheDay?.priceGuide}|${lockOfTheDay?.units}`;
  if (snap.lotd && snap.lotd !== lotdKey) {
    changes.push({
      type: "lotd",
      line: `👑 **LOCK OF THE DAY UPDATED**\n**${lockOfTheDay.pick}** · ${lockOfTheDay.priceGuide} · ${lockOfTheDay.units}u`
    });
  }

  return { changes, nextPicks, lotdKey };
}

export async function detectMediaChanges() {
  const snap = loadSnap();
  const changes = [];
  let mediaFp = JSON.stringify(liveCard.mediaFollow || []);
  try {
    const api = await fetchMediaFeed();
    if (api?.items) mediaFp += "|" + JSON.stringify(api.items).slice(0, 500);
  } catch {
    /* ignore */
  }
  if (snap.media && snap.media !== mediaFp) {
    changes.push({
      type: "media",
      line: "📡 **MEDIA / STATS MAP UPDATED** — re-check `/follow` and `/live`. Desk mapping may have shifted."
    });
  }
  return { changes, mediaFp };
}

export function commitSnapshot({ nextPicks, lotdKey, mediaFp }) {
  saveSnap({
    picks: nextPicks,
    lotd: lotdKey,
    media: mediaFp,
    ts: new Date().toISOString()
  });
}

export function changesEmbed(changes) {
  return new EmbedBuilder()
    .setColor(0xf39c12)
    .setTitle("📢 DESK UPDATE · PICKS MAY HAVE CHANGED")
    .setDescription(
      changes
        .map((c) => c.line)
        .join("\n\n")
        .slice(0, 4000) || "No material changes."
    )
    .setFooter({
      text: "EDGE PLAY · auto announce · re-size if tier moved · 21+"
    })
    .setTimestamp();
}

export function morningBundle() {
  return [
    {
      content:
        "☀️ **MORNING DESK IS LIVE**\n" +
        "Lock of the Day · leans · holds · media map — auto for today.\n" +
        "`/lotd` · `/locks` · `/lean` · `/hold` · `/live`"
    },
    { embeds: [lotdEmbed()] },
    { embeds: [locksTodayEmbed()] },
    { embeds: [leanEmbed()] },
    { embeds: [holdEmbed()] }
  ];
}

export function eveningBundle() {
  return [
    {
      content:
        "🌙 **EVENING DESK**\n" +
        "Grade tickets with `/grade` · review with `/track` · protect with `/hedge`"
    },
    { embeds: [liveCardEmbed()] }
  ];
}

/** Full change scan — call on interval */
export async function runChangeAnnounce() {
  const card = detectCardChanges();
  const media = await detectMediaChanges();
  const all = [...card.changes, ...media.changes];
  commitSnapshot({
    nextPicks: card.nextPicks,
    lotdKey: card.lotdKey,
    mediaFp: media.mediaFp
  });
  if (!all.length) return [];
  return [
    {
      content: "📢 **AUTO UPDATE** — information / media / stats moved the card",
      embeds: [changesEmbed(all)]
    }
  ];
}

export function initSnapshotIfEmpty() {
  const snap = loadSnap();
  if (snap.ts) return;
  const card = detectCardChanges();
  // detectCardChanges already builds nextPicks; commit without announcing all as "new" on first boot
  const quietPicks = {};
  for (const p of liveCard.picks || []) {
    const key = `${p.sport}|${p.game}|${p.selection}`;
    quietPicks[key] = pickFingerprint(p);
  }
  const lotdKey = `${lockOfTheDay?.pick}|${lockOfTheDay?.priceGuide}|${lockOfTheDay?.units}`;
  saveSnap({
    picks: quietPicks,
    lotd: lotdKey,
    media: JSON.stringify(liveCard.mediaFollow || []),
    ts: new Date().toISOString()
  });
}
