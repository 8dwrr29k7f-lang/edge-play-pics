/**
 * Live API client — optional Edge Play Python backend (OpticOdds).
 * Returns null when offline so the bot can fall back to static desks.
 */
import { config } from "./config.js";

const BASE = (config.apiBase || "http://localhost:3777").replace(/\/$/, "");

async function fetchJSON(path) {
  try {
    const res = await fetch(`${BASE}${path}`, {
      signal: AbortSignal.timeout(8000)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (e) {
    console.warn(`API ${path} offline:`, e.message);
    return null;
  }
}

export async function fetchBestBets() {
  return fetchJSON("/api/best-bets");
}

export async function fetchPL() {
  return fetchJSON("/api/pl");
}

export async function fetchModel() {
  return fetchJSON("/api/model");
}

export async function refreshData() {
  try {
    const res = await fetch(`${BASE}/api/refresh-data`, {
      method: "POST",
      signal: AbortSignal.timeout(20000)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (e) {
    console.warn("refresh offline:", e.message);
    return null;
  }
}

export function apiConfigured() {
  return Boolean(BASE);
}
