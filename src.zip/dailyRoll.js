/**
 * Daily auto card — builds NEW picks every calendar day (CT)
 * + live scan from ESPN public boards.
 * LOCK only when process clears; otherwise LEAN / HOLD / PASS.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { fetchMultiScores } from "./liveScores.js";
import * as desk from "./data/desk.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const STORE = path.join(__dirname, "data", "dailyCard.json");

function ctNow() {
  return new Date(
    new Date().toLocaleString("en-US", { timeZone: "America/Chicago" })
  );
}

function dateKey(d = ctNow()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function dateLabel(d = ctNow()) {
  return d.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "America/Chicago"
  }).toUpperCase();
}

function loadDaily() {
  try {
    return JSON.parse(fs.readFileSync(STORE, "utf8"));
  } catch {
    return null;
  }
}

function saveDaily(card) {
  fs.mkdirSync(path.dirname(STORE), { recursive: true });
  fs.writeFileSync(STORE, JSON.stringify(card, null, 2));
  return card;
}

/** Parse ESPN line: **AWAY @ HOME** · score · status */
function parseEspnLine(line, sport) {
  const m = line.match(/\*\*([^*]+)\*\*/);
  const game = m ? m[1].trim() : line.slice(0, 40);
  const status = line.split("·").slice(-1)[0]?.trim() || "";
  const live = /in progress|q\d|half|period|inning|live/i.test(status);
  const final = /final/i.test(status);
  return { sport: sport.toUpperCase(), game, status, live, final, raw: line };
}

function processPickFromGame(g) {
  // Default process: HOLD until SP/injury + price — never invent LOCK
  const isMnf =
    g.sport === "NFL" &&
    /NYG|GIANTS|LAR|RAMS|@/i.test(g.game);
  if (g.sport === "NFL") {
    return {
      sport: "NFL",
      tier: "LEAN",
      game: g.game + (g.status ? ` · ${g.status}` : ""),
      selection: "Shop home/road only in mid — no forced lock",
      price: "Kalshi/books · prefer ≤52¢ on soft fav",
      units: 0.25,
      why: "Auto daily NFL card: division/MNF noise. LEAN only if number improves; else PASS.",
      type: "ml",
      player: null,
      kalshi: true,
      live: g.live,
      final: g.final
    };
  }
  if (g.sport === "MLB") {
    return {
      sport: "MLB",
      tier: "HOLD",
      game: g.game + (g.status ? ` · ${g.status}` : ""),
      selection: "SP confirmed side only · 40–65¢ band",
      price: "40–65¢ / −130 to +150",
      units: 0,
      why: "Auto daily MLB: no logo locks. Confirm starter then promote HOLD→LEAN/LOCK.",
      type: "ml",
      player: null,
      kalshi: true,
      live: g.live,
      final: g.final
    };
  }
  if (g.sport === "NBA") {
    return {
      sport: "NBA",
      tier: "HOLD",
      game: g.game,
      selection: "Confirmed lineup + mid only",
      price: "playable spread / 40–65¢",
      units: 0,
      why: "Auto daily NBA: rest/lineup first.",
      type: "spread",
      player: null,
      kalshi: true,
      live: g.live,
      final: g.final
    };
  }
  return {
    sport: g.sport,
    tier: "HOLD",
    game: g.game,
    selection: "Process scan",
    price: "—",
    units: 0,
    why: "Auto listed — need price + film for upgrade.",
    type: "ml",
    player: null,
    kalshi: true,
    live: g.live,
    final: g.final
  };
}

/**
 * Build or refresh today's card from ESPN + process rules.
 * force=true rebuilds even if same day.
 */
export async function rollDailyCard({ force = false } = {}) {
  const key = dateKey();
  const existing = loadDaily();
  if (!force && existing?.dateKey === key && existing?.picks?.length) {
    // Still refresh live flags from ESPN
    return refreshLiveFlags(existing);
  }

  let boards = [];
  try {
    boards = await fetchMultiScores(["mlb", "nfl", "nba"]);
  } catch (e) {
    console.error("dailyRoll ESPN:", e.message);
  }

  const games = [];
  for (const b of boards) {
    for (const line of b.lines || []) {
      games.push(parseEspnLine(line, b.sport));
    }
  }

  const picks = games.map(processPickFromGame);

  // Always include process lanes for sports with no ESPN rows
  if (!picks.some((p) => p.sport === "NFL")) {
    picks.push({
      sport: "NFL",
      tier: "HOLD",
      game: "No NFL board on ESPN right now",
      selection: "Wait next slate",
      price: "—",
      units: 0,
      why: "Empty board — not a lock day for NFL.",
      type: "ml",
      kalshi: true
    });
  }
  if (!picks.some((p) => p.sport === "MLB")) {
    picks.push({
      sport: "MLB",
      tier: "HOLD",
      game: "No MLB games listed",
      selection: "Off day or feed empty",
      price: "—",
      units: 0,
      why: "No forced picks.",
      type: "ml",
      kalshi: true
    });
  }

  // Tennis / soccer process rows (Kalshi-tracked, not ESPN)
  picks.push({
    sport: "TENNIS",
    tier: "HOLD",
    game: "Kalshi WTA/ATP slate",
    selection: "Scan Kalshi tennis — LOCK only with form+serve write-up",
    price: "45–62¢ window preferred",
    units: 0,
    why: "Daily auto: no static tennis lock carried from prior days.",
    type: "ml",
    kalshi: true
  });
  picks.push({
    sport: "SOCCER",
    tier: "PASS",
    game: "Kalshi / EPL cards",
    selection: "Skip 1.15–1.30 badge chalk",
    price: "1.70–2.40 only",
    units: 0,
    why: "Badge tax — daily PASS unless lineup edge.",
    type: "ml",
    kalshi: true
  });

  const liveCount = picks.filter((p) => p.live).length;
  const lockOfDay = buildDefaultLotd(key, picks);

  const card = {
    dateKey: key,
    dateLabel: `${dateLabel()} · AUTO DAILY CARD`,
    updated: new Date().toISOString(),
    note:
      "Auto-rolled from ESPN + process rules. LOCK only when earned. Prior-day locks do not carry.",
    picks,
    lockOfTheDay: lockOfDay,
    leanBoard: picks
      .filter((p) => p.tier === "LEAN")
      .map((p) => ({
        who: p.selection,
        vs: p.game,
        action: "LEAN",
        onlyIf: p.price,
        units: p.units,
        why: p.why
      })),
    holdBoard: picks
      .filter((p) => p.tier === "HOLD")
      .slice(0, 8)
      .map((p) => ({
        who: p.selection,
        vs: p.game,
        action: "HOLD",
        waitFor: "SP / lineup / better ¢",
        why: p.why
      })),
    hedges: desk.liveCard?.hedges || [],
    cashoutRules: desk.liveCard?.cashoutRules || [],
    passBoard: [
      "Any prior-day LOCK that already finished",
      "Blind chalk ≥70¢ without write-up",
      "MLB without confirmed SP",
      "Soccer 1.20 homes"
    ],
    kalshiSportsTracked: desk.liveCard?.kalshiSportsTracked || [
      "Tennis",
      "NFL",
      "MLB",
      "NBA",
      "Soccer",
      "Esports"
    ],
    liveCount,
    source: "espn+process"
  };

  saveDaily(card);
  // Mirror into desk mutable exports for embeds that import desk.liveCard
  applyToDesk(card);
  console.log(
    `Daily card ${key}: ${picks.length} picks · live ${liveCount} · LOTD ${lockOfDay.pick}`
  );
  return card;
}

async function refreshLiveFlags(card) {
  try {
    const boards = await fetchMultiScores(["mlb", "nfl", "nba"]);
    const liveLines = boards.flatMap((b) =>
      (b.lines || []).map((l) => ({ sport: b.sport.toUpperCase(), line: l }))
    );
    for (const p of card.picks) {
      const hit = liveLines.find((x) =>
        p.game.split("·")[0].trim().split(/\s+/).some((w) => w.length > 2 && x.line.includes(w))
      );
      if (hit) {
        p.live = /in progress|q\d|half|live/i.test(hit.line);
        p.final = /final/i.test(hit.line);
      }
    }
    card.updated = new Date().toISOString();
    card.liveCount = card.picks.filter((p) => p.live).length;
    saveDaily(card);
    applyToDesk(card);
  } catch {
    /* keep card */
  }
  return card;
}

function buildDefaultLotd(key, picks) {
  // Prefer a live LEAN as soft LOTD message, else honest "no lock"
  const lean = picks.find((p) => p.tier === "LEAN" && !p.final);
  if (lean) {
    return {
      date: key,
      sport: lean.sport,
      event: "Auto daily",
      match: lean.game,
      pick: `${lean.selection} (process LEAN — not a forced LOCK)`,
      market: lean.type || "ml",
      priceGuide: lean.price,
      units: lean.units || 0.25,
      tier: "LOCK OF THE DAY · SOFT",
      analysis: {
        form: lean.why,
        serve: "Auto card — upgrade to full LOCK only with film + mid.",
        situational: "Live scan active. Cash-out watch on logged tickets.",
        kill: "No full write-up yet — size as LEAN max.",
        prediction: "Process lean only until desk upgrades."
      },
      kalshi: "https://kalshi.com"
    };
  }
  return {
    date: key,
    sport: "DESK",
    event: "Auto daily",
    match: "No LOCK cleared",
    pick: "No Lock of the Day — PASS forced locks",
    market: "—",
    priceGuide: "—",
    units: 0,
    tier: "NO LOCK",
    analysis: {
      form: "ESPN slate scanned. Nothing met LOCK bar (edge + juice + film).",
      serve: "HOLD/LEAN only on the live card.",
      situational: "Check /live for per-game actions.",
      kill: "Inventing a lock is how banks get burned.",
      prediction: "Sit the lock slot. Hunt value later."
    },
    kalshi: "https://kalshi.com"
  };
}

function applyToDesk(card) {
  try {
    if (desk.liveCard) {
      desk.liveCard.dateLabel = card.dateLabel;
      desk.liveCard.updated = card.updated;
      desk.liveCard.note = card.note;
      desk.liveCard.picks = card.picks;
      desk.liveCard.leanBoard = card.leanBoard;
      desk.liveCard.holdBoard = card.holdBoard;
      desk.liveCard.passBoard = card.passBoard;
      if (card.hedges) desk.liveCard.hedges = card.hedges;
    }
    if (desk.lockOfTheDay && card.lockOfTheDay) {
      Object.assign(desk.lockOfTheDay, card.lockOfTheDay);
    }
  } catch (e) {
    console.warn("applyToDesk", e.message);
  }
}

export function getDailyCard() {
  const c = loadDaily();
  if (c?.dateKey === dateKey()) return c;
  return null;
}

/** Ensure today exists — call on boot and cron */
export async function ensureTodayCard() {
  const c = getDailyCard();
  if (c) return refreshLiveFlags(c);
  return rollDailyCard({ force: true });
}
