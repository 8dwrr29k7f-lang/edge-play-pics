import { EmbedBuilder } from "discord.js";
import { lockOfTheDay, liveCard, premiumAlerts } from "./data/desk.js";
import { config } from "./config.js";

const { colors } = config;

export function lotdEmbed() {
  const L = lockOfTheDay;
  const a = L.analysis;
  return new EmbedBuilder()
    .setColor(0xf4d03f)
    .setTitle("👑 LOCK OF THE DAY · LET'S EAT")
    .setDescription(
      `**${L.pick}**\n` +
        `${L.event} · ${L.match}\n` +
        `**Market:** ${L.market}\n` +
        `**Price guide:** ${L.priceGuide}\n` +
        `**Size:** **${L.units}u** · **${L.tier}**\n\n` +
        `### Form\n${a.form}\n\n` +
        `### Serve\n${a.serve}\n\n` +
        `### Situational\n${a.situational}\n\n` +
        `### What breaks this\n${a.kill}\n\n` +
        `### Prediction\n**${a.prediction}**\n\n` +
        `📡 Kalshi: ${L.kalshi}`
    )
    .setFooter({ text: `${L.date} · EDGE PLAY PICS · /logpick after you fire · 21+` })
    .setTimestamp();
}

export function liveCardEmbed() {
  const c = liveCard;
  const e = new EmbedBuilder()
    .setColor(colors.gold)
    .setTitle("📡 LIVE CARD · WHO WE'RE ON")
    .setDescription(`**${c.dateLabel}**\nNamed takes + PASS board.`)
    .setFooter({ text: "EDGE PLAY · clear TAKE / PASS · 21+" })
    .setTimestamp();

  for (const p of c.picks) {
    const icon =
      p.tier === "LOCK"
        ? "🔒"
        : p.tier === "LEAN"
          ? "➖"
          : p.tier === "HOLD"
            ? "⏸️"
            : "🚫";
    const take =
      p.tier === "LOCK" || p.tier === "CAP"
        ? `✅ **TAKE ${p.selection}**`
        : p.tier === "LEAN"
          ? `➖ **SMALL** ${p.selection}`
          : p.tier === "HOLD"
            ? `⏸️ **HOLD** ${p.selection}`
            : `🚫 **PASS**`;
    e.addFields({
      name: `${icon} ${p.tier} · ${p.sport}`,
      value: `${take}\n**${p.game}**\nPrice: ${p.price} · **${p.units}u**\n_${p.why}_`,
      inline: false
    });
  }

  if (c.playerPicks?.length) {
    e.addFields({
      name: "👤 PLAYER / PROP LANE",
      value: c.playerPicks
        .map(
          (x) =>
            `**${x.player || x.market}** · ${x.side} · \`${x.tier}\` · ${x.units}u\n_${x.note}_`
        )
        .join("\n\n")
        .slice(0, 1000),
      inline: false
    });
  }

  if (c.leanBoard?.length) {
    e.addFields({
      name: "➖ LEAN · WHO",
      value: c.leanBoard
        .map(
          (r) =>
            `**${r.who}** vs ${r.vs}\nOnly if: ${r.onlyIf} · **${r.units}u**\n_${r.why}_`
        )
        .join("\n\n")
        .slice(0, 1000),
      inline: false
    });
  }

  if (c.holdBoard?.length) {
    e.addFields({
      name: "⏸️ HOLD · WHO",
      value: c.holdBoard
        .map(
          (r) =>
            `**${r.who}** vs ${r.vs}\nWait: ${r.waitFor}\n_${r.why}_`
        )
        .join("\n\n")
        .slice(0, 1000),
      inline: false
    });
  }

  if (c.hedges?.length) {
    e.addFields({
      name: "🛡️ HEDGE LANE",
      value: c.hedges
        .map(
          (h) =>
            `**${h.action}** · ${h.related}\nWhen: ${h.when}\n${h.how} · **${h.units}u**`
        )
        .join("\n\n")
        .slice(0, 1000),
      inline: false
    });
  }

  if (c.passBoard?.length) {
    e.addFields({
      name: "🚫 PASS BOARD",
      value: c.passBoard.map((x) => `• ${x}`).join("\n"),
      inline: false
    });
  }

  if (c.kalshiSportsTracked?.length) {
    e.addFields({
      name: "📡 KALSHI SPORTS TRACKED",
      value: c.kalshiSportsTracked.map((x) => `• ${x}`).join("\n").slice(0, 900),
      inline: false
    });
  }

  if (c.note) {
    e.setDescription(`**${c.dateLabel}**\n${c.note}`);
  }

  return e;
}

export function locksTodayEmbed() {
  const locks = liveCard.picks.filter(
    (p) => p.tier === "LOCK" || p.tier === "CAP"
  );
  const e = new EmbedBuilder()
    .setColor(0xf4d03f)
    .setTitle("🔒 LOCKS · TAKE THESE")
    .setTimestamp()
    .setFooter({ text: "EDGE PLAY · /lotd for full write-up · 21+" });

  if (!locks.length && !premiumAlerts.length) {
    return e.setDescription(
      "**Clear answer: no LOCK on the board.** Do not force one."
    );
  }

  let desc = "";
  if (lockOfTheDay) {
    desc += `**1. 👑 LOCK OF THE DAY**\n✅ **TAKE ${lockOfTheDay.pick}**\n${lockOfTheDay.priceGuide} · **${lockOfTheDay.units}u**\n${lockOfTheDay.event}\n\n`;
  }
  locks.forEach((p, i) => {
    if (p.selection.includes("Dolehide") && lockOfTheDay) return;
    desc += `**${i + 2}. 🔒 ${p.tier}**\n✅ **TAKE ${p.selection}** · ${p.price} · **${p.units}u**\n${p.game}\n_${p.why}_\n\n`;
  });
  e.setDescription(desc.slice(0, 4000));
  return e;
}
