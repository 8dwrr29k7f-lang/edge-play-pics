/**
 * Performance tracker core — pure Node, no Discord dependency.
 * Additive self-learning ledger. Does not change pick generation.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const STORE = path.join(__dirname, "data", "tracker.json");

const DEFAULT_SEED = {
  label: "day-1 reviewed picks",
  wins: 2,
  losses: 3,
  pushes: 0,
  units: -1.86,
  roiPct: -31.6,
  source: "manual review first slate"
};

export function load() {
  try {
    const data = JSON.parse(fs.readFileSync(STORE, "utf8"));
    if (!data.seedSummary) data.seedSummary = { ...DEFAULT_SEED };
    if (!Array.isArray(data.picks)) data.picks = [];
    return data;
  } catch {
    return {
      version: 1,
      updatedAt: new Date().toISOString(),
      seedSummary: { ...DEFAULT_SEED },
      picks: []
    };
  }
}

export function save(data) {
  data.updatedAt = new Date().toISOString();
  data.version = data.version || 1;
  fs.mkdirSync(path.dirname(STORE), { recursive: true });
  fs.writeFileSync(STORE, JSON.stringify(data, null, 2));
  return data;
}

export function americanToImplied(odds) {
  const o = Number(odds);
  if (!Number.isFinite(o) || o === 0) return null;
  if (o > 0) return 100 / (o + 100);
  return Math.abs(o) / (Math.abs(o) + 100);
}

export function plFromResult(units, odds, result) {
  const u = Number(units) || 0;
  const o = Number(odds);
  const r = String(result || "").toLowerCase();
  if (r === "push" || r === "p") return 0;
  if (r === "loss" || r === "l" || r === "lose") return -Math.abs(u);
  if (r === "win" || r === "w") {
    if (!Number.isFinite(o)) return u;
    if (o > 0) return u * (o / 100);
    return u * (100 / Math.abs(o));
  }
  return null;
}

function inferSideClass(odds) {
  const o = Number(odds);
  if (!Number.isFinite(o)) return "unknown";
  if (o < 0) return "favorite";
  if (o > 0) return "dog";
  return "pickem";
}

export function listPicks({ limit = 25, pendingOnly = false } = {}) {
  const data = load();
  let rows = data.picks || [];
  if (pendingOnly) rows = rows.filter((p) => !p.result || p.result === "pending");
  return rows.slice(-limit).reverse();
}

export function logPick(input) {
  const data = load();
  const id =
    input.id ||
    `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const reasons = Array.isArray(input.reasons)
    ? input.reasons
    : String(input.reasons || input.analysis || "")
        .split(/[|;\n]+/)
        .map((s) => s.trim())
        .filter(Boolean);
  const row = {
    id,
    ts: input.ts || new Date().toISOString(),
    sport: String(input.sport || "unknown").toUpperCase(),
    betType: String(input.betType || input.market || "ml").toLowerCase(),
    market: String(input.market || input.betType || "ml"),
    selection: String(input.selection || input.pick || ""),
    game: String(input.game || ""),
    odds: Number(input.odds),
    units: Number(input.units) || 0.5,
    confidence: Number(input.confidence || input.score || 0) || null,
    label: String(input.label || input.tier || "VALUE").toUpperCase(),
    sideClass: String(input.sideClass || "").toLowerCase() || inferSideClass(input.odds),
    reasons,
    book: input.book || "",
    result: input.result || "pending",
    pl: input.pl ?? null,
    closingOdds: input.closingOdds ?? null,
    clv: input.clv ?? null,
    notes: input.notes || ""
  };
  data.picks.push(row);
  save(data);
  return row;
}

export function gradePick({ id, selection, result, closingOdds, notes } = {}) {
  const data = load();
  let row = null;
  if (id) row = data.picks.find((p) => p.id === id);
  if (!row && selection) {
    row = [...data.picks]
      .reverse()
      .find(
        (p) =>
          p.selection.toLowerCase().includes(String(selection).toLowerCase()) &&
          (!p.result || p.result === "pending")
      );
  }
  if (!row) return null;

  row.result = String(result).toLowerCase();
  if (closingOdds != null && closingOdds !== "") {
    row.closingOdds = Number(closingOdds);
    if (Number.isFinite(row.odds) && Number.isFinite(row.closingOdds)) {
      const openImp = americanToImplied(row.odds);
      const closeImp = americanToImplied(row.closingOdds);
      if (openImp != null && closeImp != null) {
        row.clv = Number(((closeImp - openImp) * 100).toFixed(2));
      }
    }
  }
  if (notes) row.notes = notes;
  row.pl = plFromResult(row.units, row.odds, row.result);
  save(data);
  return row;
}

export function summaryStats() {
  const data = load();
  const graded = (data.picks || []).filter((p) =>
    ["win", "loss", "push"].includes(String(p.result || "").toLowerCase())
  );

  let wins = 0,
    losses = 0,
    pushes = 0,
    units = 0,
    risked = 0;

  for (const p of graded) {
    const r = p.result.toLowerCase();
    if (r === "win") wins++;
    else if (r === "loss") losses++;
    else pushes++;
    const pl =
      p.pl != null ? Number(p.pl) : plFromResult(p.units, p.odds, p.result);
    units += pl || 0;
    risked += Math.abs(Number(p.units) || 0);
  }

  const seed = data.seedSummary || DEFAULT_SEED;
  const usedSeed = graded.length === 0;
  if (usedSeed) {
    wins = seed.wins;
    losses = seed.losses;
    pushes = seed.pushes || 0;
    units = seed.units;
    risked = Math.abs(seed.units) / (Math.abs(seed.roiPct) / 100 || 0.316) || 5.9;
  }

  const decided = wins + losses;
  const winPct = decided ? (wins / decided) * 100 : 0;
  const roi = usedSeed
    ? seed.roiPct
    : risked
      ? (units / risked) * 100
      : 0;

  return {
    wins,
    losses,
    pushes,
    units: Number(Number(units).toFixed(2)),
    risked: Number(Number(risked).toFixed(2)),
    winPct: Number(winPct.toFixed(1)),
    roi: Number(Number(roi).toFixed(1)),
    graded: graded.length,
    pending: (data.picks || []).filter((p) => !p.result || p.result === "pending")
      .length,
    usedSeed,
    seed
  };
}

function groupBy(rows, keyFn) {
  const map = new Map();
  for (const p of rows) {
    const k = keyFn(p) || "unknown";
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(p);
  }
  return map;
}

function bucketStats(rows) {
  let w = 0,
    l = 0,
    u = 0,
    risk = 0;
  for (const p of rows) {
    const r = String(p.result || "").toLowerCase();
    if (r === "win") w++;
    else if (r === "loss") l++;
    const pl =
      p.pl != null ? Number(p.pl) : plFromResult(p.units, p.odds, p.result);
    u += pl || 0;
    risk += Math.abs(Number(p.units) || 0);
  }
  const d = w + l;
  return {
    n: rows.length,
    record: `${w}-${l}`,
    winPct: d ? Number(((w / d) * 100).toFixed(1)) : 0,
    units: Number(u.toFixed(2)),
    roi: risk ? Number(((u / risk) * 100).toFixed(1)) : 0
  };
}

function oddsRange(odds) {
  const o = Number(odds);
  if (!Number.isFinite(o)) return "unknown";
  if (o <= -200) return "big_fav_(-200up)";
  if (o <= -140) return "fav_(-199_-140)";
  if (o < 0) return "slight_fav_(-139_-100)";
  if (o <= 140) return "slight_dog_(+100_+140)";
  if (o <= 200) return "dog_(+141_+200)";
  return "longshot_(+200up)";
}

export function analyzePatterns() {
  const data = load();
  const graded = (data.picks || []).filter((p) =>
    ["win", "loss", "push"].includes(String(p.result || "").toLowerCase())
  );
  const insights = [];

  if (graded.length < 5) {
    insights.push({
      level: "info",
      text: `Only **${graded.length}** graded legs in the ledger. Day-1 seed was **2-3 (−1.86u, −31.6% ROI)** — treat as one data point, not a regime change. Keep logging.`
    });
  }

  const byLabel = groupBy(graded, (p) => (p.label || "VALUE").toUpperCase());
  for (const [label, rows] of byLabel) {
    if (rows.length < 3) continue;
    const s = bucketStats(rows);
    insights.push({
      level: s.roi >= 0 ? "good" : "warn",
      text: `**${label}** label: ${s.record} · ${s.units >= 0 ? "+" : ""}${s.units}u · ROI ${s.roi}% (n=${s.n})`
    });
  }

  const byType = groupBy(graded, (p) => p.betType || p.market || "ml");
  for (const [t, rows] of byType) {
    if (rows.length < 3) continue;
    const s = bucketStats(rows);
    insights.push({
      level: s.roi >= 0 ? "good" : "warn",
      text: `Bet type **${t}**: ${s.record} · ${s.units >= 0 ? "+" : ""}${s.units}u · ROI ${s.roi}%`
    });
  }

  const bySide = groupBy(graded, (p) => p.sideClass || inferSideClass(p.odds));
  for (const [side, rows] of bySide) {
    if (rows.length < 3) continue;
    const s = bucketStats(rows);
    insights.push({
      level: s.roi >= 0 ? "good" : "warn",
      text: `**${side}**: ${s.record} · ${s.units >= 0 ? "+" : ""}${s.units}u · ROI ${s.roi}%`
    });
  }

  const byOdds = groupBy(graded, (p) => oddsRange(p.odds));
  for (const [band, rows] of byOdds) {
    if (rows.length < 3) continue;
    const s = bucketStats(rows);
    insights.push({
      level: s.roi >= 0 ? "good" : "warn",
      text: `Odds **${band}**: ${s.record} · ${s.units >= 0 ? "+" : ""}${s.units}u · ROI ${s.roi}%`
    });
  }

  const withConf = graded.filter((p) => p.confidence != null);
  if (withConf.length >= 5) {
    const buckets = [
      ["conf≥70", withConf.filter((p) => p.confidence >= 70)],
      ["conf 50–69", withConf.filter((p) => p.confidence >= 50 && p.confidence < 70)],
      ["conf<50", withConf.filter((p) => p.confidence < 50)]
    ];
    for (const [name, rows] of buckets) {
      if (rows.length < 2) continue;
      const s = bucketStats(rows);
      insights.push({
        level: "info",
        text: `Calibration **${name}**: win% ${s.winPct} · ${s.record} · ROI ${s.roi}%`
      });
    }
  }

  const reasonCount = (rows) => {
    const m = new Map();
    for (const p of rows) {
      for (const r of p.reasons || []) {
        const k = r.toLowerCase().slice(0, 48);
        m.set(k, (m.get(k) || 0) + 1);
      }
    }
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  };
  const lossReasons = reasonCount(
    graded.filter((p) => p.result === "loss")
  ).slice(0, 5);
  const winReasons = reasonCount(
    graded.filter((p) => p.result === "win")
  ).slice(0, 5);
  if (lossReasons.length) {
    insights.push({
      level: "warn",
      text:
        "Reasons most common on **losses**: " +
        lossReasons.map(([r, n]) => `\`${r}\`(${n})`).join(", ")
    });
  }
  if (winReasons.length) {
    insights.push({
      level: "good",
      text:
        "Reasons most common on **wins**: " +
        winReasons.map(([r, n]) => `\`${r}\`(${n})`).join(", ")
    });
  }

  const locks = byLabel.get("LOCK") || [];
  const values = [...(byLabel.get("VALUE") || []), ...(byLabel.get("CAP") || [])];
  if (locks.length >= 2 && values.length >= 2) {
    const ls = bucketStats(locks);
    const vs = bucketStats(values);
    insights.push({
      level: ls.roi >= vs.roi ? "good" : "warn",
      text: `LOCK ROI **${ls.roi}%** (n=${ls.n}) vs VALUE/CAP ROI **${vs.roi}%** (n=${vs.n}) — ${ls.roi >= vs.roi ? "LOCK label earning its hierarchy" : "LOCK not outperforming VALUE yet — tighten bar"}`
    });
  }

  insights.push({
    level: "info",
    text: "**ph0 process:** no-vig fair price · only +EV tickets · LOCK must earn ROI over time · record close for CLV"
  });

  const withClose = graded.filter(
    (p) => p.closingOdds != null && Number.isFinite(Number(p.odds))
  );
  if (withClose.length >= 3) {
    let beat = 0;
    for (const p of withClose) {
      const o = americanToImplied(p.odds);
      const c = americanToImplied(p.closingOdds);
      if (o != null && c != null && c > o) beat++;
    }
    insights.push({
      level: beat / withClose.length >= 0.5 ? "good" : "warn",
      text: `CLV sample: **${beat}/${withClose.length}** closes moved toward our number — pass closing odds on /grade`
    });
  }

  if (!insights.length) {
    insights.push({
      level: "info",
      text: "Not enough graded history for splits. Log + grade picks; patterns unlock after ~10–15 results."
    });
  }

  return { insights, graded: graded.length, summary: summaryStats() };
}

export function ingestLivePicks(payload) {
  if (!payload?.picks?.length) return 0;
  const data = load();
  const existing = new Set(
    data.picks.map(
      (p) => `${p.game}|${p.selection}|${p.odds}|${String(p.ts || "").slice(0, 10)}`
    )
  );
  let n = 0;
  const day = new Date().toISOString().slice(0, 10);
  for (const p of payload.picks) {
    const key = `${p.game}|${p.selection}|${p.price}|${day}`;
    if (existing.has(key)) continue;
    logPick({
      sport: p.sport_name || p.sport,
      betType: p.market,
      market: p.market,
      selection: p.selection,
      game: p.game,
      odds: p.price,
      units: p.units,
      confidence: p.score,
      label: p.tier,
      reasons: p.analysis,
      book: p.book
    });
    n++;
  }
  return n;
}

export function ensureSeedFile() {
  const data = load();
  if (!data.seedSummary) data.seedSummary = { ...DEFAULT_SEED };
  save(data);
  return data;
}
