/**
 * Live picks embeds — OpticOdds when API is up; static desk fallback when not.
 * LOCK answers are explicit: TAKE THIS / PASS — no buried templates.
 */
import { EmbedBuilder } from "discord.js";
import { config } from "./config.js";
import { fetchBestBets, fetchPL } from "./liveApi.js";
import { categories } from "./data/desk.js";

const { colors } = config;

function base(color = colors.navy) {
  return new EmbedBuilder()
    .setColor(color)
    .setTimestamp()
    .setFooter({ text: "⚡ EDGE PLAY PICS · clear TAKE / PASS · 21+" });
}

const TIER_EMOJI = {
  LOCK: "🔒",
  CAP: "✅",
  VALUE: "💎",
  LEAN: "➖",
  WATCH: "👀",
  PASS: "🚫",
  FADE: "❌"
};

function offlineBanner() {
  return (
    "_Odds API offline — process bars only (not named game locks). " +
    "Start OpticOdds backend + set EDGE_PLAY_API for live TAKE lines._\n\n"
  );
}

function formatPrice(p) {
  if (p == null || p === 0) return "—";
  return p > 0 ? `+${p}` : `${p}`;
}

/** One-line clear instruction */
function actionLine(p) {
  const price = formatPrice(p.price);
  const tier = (p.tier || "VALUE").toUpperCase();
  if (tier === "LOCK" || tier === "CAP") {
    return `✅ **TAKE THIS · ${tier}** → **${p.selection}** ${price} · **${p.units}u** · ${p.book || "shop"}`;
  }
  if (tier === "VALUE") {
    return `💎 **TAKE (VALUE)** → **${p.selection}** ${price} · **${p.units}u**`;
  }
  if (tier === "LEAN") {
    return `➖ **SMALL ONLY** → **${p.selection}** ${price} · **${p.units}u**`;
  }
  return `🚫 **PASS** → ${p.selection} ${price}`;
}

export async function liveBestBetsEmbed() {
  const data = await fetchBestBets();
  if (!data || !data.picks || data.picks.length === 0) {
    const lines = Object.values(categories)
      .map(
        (c) =>
          `**${c.emoji} ${c.label}**\n` +
          `Process: ${c.best.pick}\n` +
          `_Band ${c.best.odds} · ${c.best.size}_ · not a named lock until live feed`
      )
      .join("\n\n");
    return base(colors.gold)
      .setTitle("⭐ BEST TAKES")
      .setDescription(
        (
          offlineBanner() +
          "**No live LOCK card right now.**\n" +
          "When OpticOdds is up, TAKE lines appear here first.\n\n" +
          lines
        ).slice(0, 4000)
      );
  }

  const locks = data.picks.filter(
    (p) => p.tier === "LOCK" || p.tier === "CAP"
  );
  const rest = data.picks.filter(
    (p) => p.tier !== "LOCK" && p.tier !== "CAP"
  );

  const e = base(0xf4d03f).setTitle("🔥 EDGE PLAY · WHAT TO TAKE");

  let desc =
    `**${data.total_picks} bets · ${data.total_units}u · ${data.sports_count} sports**\n` +
    `${data.generated_at || ""}\n\n`;

  if (locks.length) {
    desc += "### 🔒 CLEAR LOCKS — TAKE THESE\n";
    desc += locks.map(actionLine).join("\n") + "\n\n";
  } else {
    desc += "### 🔒 CLEAR LOCKS\n_None qualified — **do not force a lock.**_\n\n";
  }

  e.setDescription(desc.slice(0, 2000));

  // Detail fields for locks first
  for (const p of locks.slice(0, 6)) {
    e.addFields({
      name: `${TIER_EMOJI[p.tier] || "🔒"} ${p.tier} · ${p.sport_name} · ${formatPrice(p.price)}`,
      value:
        `**TAKE: ${p.selection}** · ${p.units}u · ${p.book}\n` +
        `${p.game}\n` +
        `${p.market} · Score ${p.score}/100\n` +
        `${p.pick_line || ""}\n` +
        `_${p.analysis || ""}_`,
      inline: false
    });
  }

  for (const p of rest.slice(0, 6)) {
    const emoji = TIER_EMOJI[p.tier] || "📊";
    e.addFields({
      name: `${emoji} ${p.tier} · ${p.sport_name} · ${p.selection} ${formatPrice(p.price)}`,
      value: `${p.game} · ${p.units}u · ${p.book} · ${p.analysis || ""}`.slice(
        0,
        300
      ),
      inline: false
    });
  }

  return e;
}

export async function liveLocksEmbed() {
  const data = await fetchBestBets();

  if (!data || !data.picks) {
    return base(colors.gold)
      .setTitle("🔒 LOCKS — WHAT TO TAKE")
      .setDescription(
        offlineBanner() +
          "**No live named locks.**\n\n" +
          "Answer: **PASS the lock board** until OpticOdds returns LOCK/CAP.\n" +
          "Use sport desks (`/mlb` `/kbo` …) for process bands only.\n" +
          "Do **not** invent a lock."
      );
  }

  const locks = data.picks.filter(
    (p) => p.tier === "LOCK" || p.tier === "CAP"
  );

  if (locks.length === 0) {
    return base(colors.gold)
      .setTitle("🔒 LOCKS — WHAT TO TAKE")
      .setDescription(
        `**Clear answer: NO LOCKS TO TAKE right now.**\n\n` +
          `Live feed ran · **${data.total_picks}** other picks · **${data.total_units}u** on board\n` +
          `Nothing cleared LOCK/CAP bar (ph0 edge + juice).\n\n` +
          `**Do not force a lock.** Sit or use /best for VALUE only.`
      );
  }

  const totalU = locks.reduce((s, p) => s + (p.units || 0), 0);
  const e = base(0xf4d03f)
    .setTitle("🔒 LOCKS — TAKE THESE")
    .setDescription(
      `**${locks.length} clear take(s) · ${totalU}u total**\n\n` +
        locks.map((p, i) => `**${i + 1}.** ${actionLine(p)}`).join("\n\n")
    );

  for (const p of locks.slice(0, 8)) {
    e.addFields({
      name: `${TIER_EMOJI[p.tier]} ${p.tier} · ${p.sport_name}`,
      value:
        `✅ **TAKE ${p.selection}** ${formatPrice(p.price)}\n` +
        `**Game:** ${p.game}\n` +
        `**Market:** ${p.market} · **Book:** ${p.book}\n` +
        `**Size:** ${p.units}u · **Score:** ${p.score}/100\n` +
        `**Why:** ${p.analysis || "edge cleared bar"}`,
      inline: false
    });
  }

  e.addFields({
    name: "Rules",
    value: "Shop the number · max 1–2 tickets · grade with `/grade` · 21+",
    inline: false
  });

  return e;
}

export async function livePLEmbed() {
  const data = await fetchPL();
  if (!data) {
    return base(colors.gold)
      .setTitle("📊 P/L TRACKER")
      .setDescription(
        offlineBanner() +
          "Use Discord **`/track`** for the self-learning ledger (day-1 seed 2–3 / −1.86u)."
      );
  }

  const color = (data.roi || 0) >= 0 ? 0x2ecc71 : 0xe74c3c;
  return base(color)
    .setTitle("📊 EDGE PLAY · P/L")
    .setDescription(
      `**Record:** ${data.wins}W - ${data.losses}L - ${data.pushes}P\n` +
        `**Units:** ${data.total_units >= 0 ? "+" : ""}${Number(data.total_units).toFixed(1)}u\n` +
        `**ROI:** ${data.roi >= 0 ? "+" : ""}${Number(data.roi).toFixed(1)}%\n` +
        `**Locks:** ${data.locks}W - ${data.locks_l}L`
    );
}

export async function liveAllPicksEmbed() {
  const data = await fetchBestBets();
  if (!data || !data.picks || data.picks.length === 0) {
    return liveBestBetsEmbed();
  }

  const e = base(colors.navy)
    .setTitle("📊 ALL PICKS")
    .setDescription(
      `**${data.total_picks} picks · ${data.total_units}u**\n` +
        `Top lines = what to take first.\n\n` +
        data.picks
          .slice(0, 12)
          .map(actionLine)
          .join("\n")
          .slice(0, 3500)
    );
  return e;
}
