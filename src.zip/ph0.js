/**
 * ph0-style process helpers — strategic filters, not magic locks.
 * Core: no-vig fair price → edge vs offered → size only with +EV.
 * Record outcomes → review → tighten labels (LOCK must earn it).
 */

/** American odds → implied probability */
export function impliedProb(american) {
  const o = Number(american);
  if (!Number.isFinite(o) || o === 0) return null;
  if (o > 0) return 100 / (o + 100);
  return Math.abs(o) / (Math.abs(o) + 100);
}

/** Two-way no-vig probs from American pair */
export function noVigPair(oddsA, oddsB) {
  const pA = impliedProb(oddsA);
  const pB = impliedProb(oddsB);
  if (pA == null || pB == null) return null;
  const s = pA + pB;
  if (s <= 0) return null;
  return { fairA: pA / s, fairB: pB / s, vig: s - 1 };
}

/** Rough EV in units for staking `units` at american odds with fairProb */
export function expectedValueUnits(units, american, fairProb) {
  const u = Number(units) || 0;
  const o = Number(american);
  const p = Number(fairProb);
  if (!Number.isFinite(o) || !Number.isFinite(p)) return null;
  const win = o > 0 ? u * (o / 100) : u * (100 / Math.abs(o));
  // EV = p * win - (1-p) * u
  return p * win - (1 - p) * u;
}

/**
 * ph0 gate — should this price even be considered?
 * Returns { ok, reasons[], edgeHint }
 */
export function ph0Gate({
  american,
  fairProb,
  label = "VALUE",
  publicPct = null
} = {}) {
  const reasons = [];
  const imp = impliedProb(american);
  if (imp == null) {
    return { ok: false, reasons: ["bad odds"], edgeHint: null };
  }

  // Juice traps
  if (american <= -200) {
    reasons.push("big-fav tax (−200 or shorter)");
  }
  if (publicPct != null && publicPct >= 80 && american < 0) {
    reasons.push("80%+ public favorite");
  }

  let edgeHint = null;
  if (fairProb != null) {
    edgeHint = fairProb - imp; // positive = model/fair above market implied
    if (edgeHint < 0.01) reasons.push("no clear +EV vs fair");
    if (edgeHint >= 0.03) reasons.push("ph0: solid edge vs fair (≥3pp)");
  }

  const lab = String(label).toUpperCase();
  if (lab === "LOCK" && edgeHint != null && edgeHint < 0.025) {
    reasons.push("LOCK label needs stronger edge — demote to VALUE");
  }

  const hardFail = reasons.some((r) =>
    /tax|80%|no clear|demote/.test(r)
  );
  // soft notes can still ok
  const ok =
    !reasons.some((r) =>
      /bad odds|tax|80%|no clear \+EV|demote/.test(r)
    );

  return { ok, reasons, edgeHint, implied: imp };
}

export const PH0_RULES = [
  "Convert odds → implied → remove vig when two-way available",
  "Bet only when fair/model edge clears a real threshold (not vibes)",
  "LOCK must beat VALUE on realized ROI over time — tracker enforces honesty",
  "Record every pick: odds, units, label, reasons, result, close",
  "Review weekly: kill factors that show up on losses",
  "Day-1 red day is a data point — update process, don’t chase"
];
