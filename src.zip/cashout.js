/**
 * Cash-out / hedge alerts — automatic channel announcements
 * CASH OUT NOW vs HEDGE CHECK vs PROTECT
 */
import { EmbedBuilder } from "discord.js";
import { listPicks } from "./trackerCore.js";
import { fetchMultiScores } from "./liveScores.js";
import { liveCard, lockOfTheDay } from "./data/desk.js";

const sent = new Map();
const COOLDOWN_MS = 30 * 60 * 1000; // 30m per key so urgent can re-fire later

function cool(key, ms = COOLDOWN_MS) {
  const t = sent.get(key);
  if (t && Date.now() - t < ms) return false;
  sent.set(key, Date.now());
  return true;
}

function embedCash({ title, body, level }) {
  const color =
    level === "now" ? 0xc0392b : level === "strong" ? 0xe74c3c : 0xe67e22;
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(body)
    .setFooter({
      text: "EDGE PLAY · auto cash-out desk · not a broker order · 21+"
    })
    .setTimestamp();
}

function watchList() {
  const pending = listPicks({ limit: 40, pendingOnly: true });
  const watches = [];

  for (const p of pending) {
    watches.push({
      id: p.id,
      selection: p.selection,
      sport: (p.sport || "").toUpperCase(),
      units: p.units,
      label: p.label,
      odds: p.odds,
      keywords: String(p.selection + " " + (p.game || ""))
        .toUpperCase()
        .split(/[^A-Z0-9]+/)
        .filter((w) => w.length >= 3)
    });
  }

  if (lockOfTheDay?.pick) {
    watches.push({
      id: "lotd",
      selection: lockOfTheDay.pick,
      sport: "TENNIS",
      units: lockOfTheDay.units,
      label: "LOCK",
      keywords: ["DOLEHIDE", "ZARAZUA"]
    });
  }

  // live card LOCK/LEAN names
  for (const p of liveCard.picks || []) {
    if (!["LOCK", "CAP", "LEAN", "VALUE"].includes(p.tier)) continue;
    const words = String(p.selection + " " + (p.game || ""))
      .toUpperCase()
      .split(/[^A-Z0-9]+/)
      .filter((w) => w.length >= 3);
    watches.push({
      id: `card-${p.selection}`,
      selection: p.selection,
      sport: p.sport,
      units: p.units,
      label: p.tier,
      keywords: words.slice(0, 6)
    });
  }

  return watches;
}

/**
 * Parse "AWAY @ HOME · 7–21 · Q3" style lines
 */
function parseLine(line) {
  const score = line.match(/(\d+)\s*[–\-]\s*(\d+)/);
  const live = /Q\d|HALF|INN|PROGRESS|1ST|2ND|3RD|4TH|OT|LIVE/i.test(line);
  const final = /FINAL/i.test(line);
  return {
    a: score ? Number(score[1]) : null,
    b: score ? Number(score[2]) : null,
    diff: score ? Math.abs(Number(score[1]) - Number(score[2])) : 0,
    live: live && !final,
    final,
    line
  };
}

export async function scanCashoutAlerts() {
  const alerts = [];
  const watches = watchList();
  if (!watches.length) return alerts;

  let boards = [];
  try {
    boards = await fetchMultiScores(["mlb", "nfl", "nba"]);
  } catch {
    return alerts;
  }

  const allLines = boards.flatMap((b) =>
    (b.lines || []).map((line) => ({ line, sport: b.sport }))
  );

  for (const w of watches) {
    for (const { line, sport } of allLines) {
      const U = line.toUpperCase();
      if (!w.keywords.some((k) => U.includes(k))) continue;

      const st = parseLine(line);
      if (!st.live && !st.final) continue;
      if (st.a == null) continue;

      const isNFL = (w.sport || sport || "").match(/NFL|FOOTBALL/i);
      const isMLB = (w.sport || sport || "").match(/MLB|BASEBALL/i);

      // Thresholds
      let level = null; // now | strong | soft
      if (isNFL) {
        if (st.diff >= 17 && /Q3|Q4|2ND HALF|HALF/i.test(line)) level = "now";
        else if (st.diff >= 14) level = "strong";
        else if (st.diff >= 10) level = "soft";
      } else if (isMLB) {
        if (st.diff >= 6 && /7TH|8TH|9TH/i.test(line)) level = "now";
        else if (st.diff >= 5) level = "strong";
        else if (st.diff >= 4) level = "soft";
      } else {
        if (st.diff >= 20) level = "strong";
        else if (st.diff >= 12) level = "soft";
      }

      if (!level) continue;

      const key = `cash-${level}-${w.id}-${st.a}-${st.b}`;
      const cd = level === "now" ? 20 * 60 * 1000 : COOLDOWN_MS;
      if (!cool(key, cd)) continue;

      if (level === "now") {
        alerts.push({
          content:
            "💸 **CASH OUT NOW** — ticket is underwater · protect the bag",
          embeds: [
            embedCash({
              level: "now",
              title: "💸 CASH OUT NOW",
              body:
                `**Tracked:** ${w.selection} · \`${w.label}\` · **${w.units}u**\n` +
                `**Live:** ${line}\n\n` +
                `Margin **${st.diff}** late enough that the desk says:\n` +
                `✅ **Cash out if the book/Kalshi offers value**\n` +
                `🛡️ Or **hedge ≤ ${Math.min(0.25, Number(w.units) || 0.25)}u** — do **not** full reverse\n\n` +
                `After: \`/grade\` the result · \`/hedge\` for rules`
            })
          ]
        });
      } else if (level === "strong") {
        alerts.push({
          content: "🚨 **SHOULD CASH / HEDGE** — looks bad live",
          embeds: [
            embedCash({
              level: "strong",
              title: "🚨 SHOULD CASH OUT OR HEDGE",
              body:
                `**Tracked:** ${w.selection} · \`${w.label}\` · **${w.units}u**\n` +
                `**Live:** ${line}\n\n` +
                `Margin **${st.diff}** while live.\n` +
                `**Desk:** Strongly consider **cash out** or a **small hedge**.\n` +
                `Do not chase. Ladder: LOCK → HEDGE → CASH → stop.`
            })
          ]
        });
      } else {
        alerts.push({
          content: "⚠️ **CASH-OUT WATCH** — game tilting",
          embeds: [
            embedCash({
              level: "soft",
              title: "⚠️ CASH-OUT WATCH",
              body:
                `**Tracked:** ${w.selection} · \`${w.label}\` · **${w.units}u**\n` +
                `**Live:** ${line}\n\n` +
                `Margin **${st.diff}**. Not mandatory cash yet — **watch closely**.\n` +
                `If it widens one more score, treat as **SHOULD CASH**.`
            })
          ]
        });
      }
    }
  }

  return alerts;
}

export function hedgesEmbed() {
  const hedges = liveCard.hedges || [];
  const rules = liveCard.cashoutRules || [];
  const e = new EmbedBuilder()
    .setColor(0xe67e22)
    .setTitle("🛡️ HEDGES & AUTO CASH-OUT")
    .setDescription(
      "Bot **auto-posts** when tracked picks look bad live:\n" +
        "💸 **CASH OUT NOW** · 🚨 **SHOULD CASH/HEDGE** · ⚠️ **WATCH**\n\n" +
        "Log picks with `/logpick` so watchers attach. LOTD is always watched."
    )
    .setFooter({ text: "EDGE PLAY · protect the ticket · 21+" })
    .setTimestamp();

  for (const h of hedges) {
    e.addFields({
      name: `🛡️ ${h.action} · ${h.related}`,
      value: `**When:** ${h.when}\n**How:** ${h.how}\n**Size:** ${h.units}u`,
      inline: false
    });
  }

  e.addFields({
    name: "Auto thresholds (approx)",
    value:
      "NFL: down 10+ watch · 14+ should cash · 17+ late **CASH NOW**\n" +
      "MLB: down 4+ watch · 5+ should · 6+ late **CASH NOW**\n" +
      "Tennis LOTD: use `/hedge` rules (set down → hedge path)",
    inline: false
  });

  if (rules.length) {
    e.addFields({
      name: "Rules",
      value: rules.map((r) => `• ${r}`).join("\n"),
      inline: false
    });
  }

  return e;
}
