/**
 * Learning layer on top of trackerCore —
 * turns graded history into forward-looking weights for future cards.
 * Does not invent locks; adjusts confidence / warnings.
 */
import { load, summaryStats, analyzePatterns, plFromResult } from "./trackerCore.js";
import { EmbedBuilder } from "discord.js";
import { config } from "./config.js";

function gradedPicks() {
  return (load().picks || []).filter((p) =>
    ["win", "loss", "push"].includes(String(p.result || "").toLowerCase())
  );
}

function bucket(rows) {
  let w = 0,
    l = 0,
    u = 0,
    risk = 0;
  for (const p of rows) {
    const r = String(p.result).toLowerCase();
    if (r === "win") w++;
    else if (r === "loss") l++;
    const pl =
      p.pl != null ? Number(p.pl) : plFromResult(p.units, p.odds, p.result);
    u += pl || 0;
    risk += Math.abs(Number(p.units) || 0);
  }
  const d = w + l;
  return {
    n: rows.length,
    w,
    l,
    units: Number(u.toFixed(2)),
    winPct: d ? (w / d) * 100 : 0,
    roi: risk ? (u / risk) * 100 : 0,
    risk
  };
}

/** Performance by sport / label / betType / odds band / side */
export function buildModel() {
  const rows = gradedPicks();
  const model = {
    sample: rows.length,
    overall: summaryStats(),
    bySport: {},
    byLabel: {},
    byBetType: {},
    bySide: {},
    byOddsBand: {},
    reasonLoss: {},
    reasonWin: {},
    recommendations: []
  };

  const band = (odds) => {
    const o = Number(odds);
    if (!Number.isFinite(o)) return "unknown";
    if (o <= -200) return "big_fav";
    if (o <= -140) return "fav";
    if (o < 0) return "slight_fav";
    if (o <= 140) return "slight_dog";
    if (o <= 200) return "dog";
    return "longshot";
  };

  for (const p of rows) {
    const sport = (p.sport || "UNK").toUpperCase();
    const label = (p.label || "VALUE").toUpperCase();
    const bt = (p.betType || p.market || "ml").toLowerCase();
    const side = p.sideClass || (Number(p.odds) < 0 ? "favorite" : "dog");
    const ob = band(p.odds);
    for (const [map, key] of [
      [model.bySport, sport],
      [model.byLabel, label],
      [model.byBetType, bt],
      [model.bySide, side],
      [model.byOddsBand, ob]
    ]) {
      if (!map[key]) map[key] = [];
      map[key].push(p);
    }
    const target =
      p.result === "loss" ? model.reasonLoss : p.result === "win" ? model.reasonWin : null;
    if (target) {
      for (const r of p.reasons || []) {
        const k = r.toLowerCase().slice(0, 40);
        target[k] = (target[k] || 0) + 1;
      }
    }
  }

  // collapse to stats
  for (const map of [
    model.bySport,
    model.byLabel,
    model.byBetType,
    model.bySide,
    model.byOddsBand
  ]) {
    for (const k of Object.keys(map)) {
      map[k] = bucket(map[k]);
    }
  }

  // Forward-looking rules
  if (model.sample < 5) {
    model.recommendations.push(
      "Sample still small (day-1 seed 2-3 / −1.86u counts as context only). Log + grade every ticket — model sharpens after ~15 graded legs."
    );
  }

  for (const [label, s] of Object.entries(model.byLabel)) {
    if (s.n < 3) continue;
    if (label === "LOCK" && s.roi < 0) {
      model.recommendations.push(
        `LOCK label is **underwater** (${s.w}-${s.l}, ROI ${s.roi.toFixed(1)}%) — raise the bar; fewer LOCKs until ROI recovers.`
      );
    }
    if (label === "LOCK" && s.roi > 5 && s.n >= 5) {
      model.recommendations.push(
        `LOCK label **earning it** (${s.w}-${s.l}, ROI +${s.roi.toFixed(1)}%) — keep strict criteria, don't loosen.`
      );
    }
    if ((label === "LEAN" || label === "VALUE") && s.roi < -15 && s.n >= 4) {
      model.recommendations.push(
        `${label} ROI **${s.roi.toFixed(1)}%** — cut size or skip this tier until fixed.`
      );
    }
  }

  for (const [sport, s] of Object.entries(model.bySport)) {
    if (s.n < 3) continue;
    if (s.roi <= -20) {
      model.recommendations.push(
        `**${sport}** cold (${s.w}-${s.l}, ${s.roi.toFixed(1)}% ROI) — reduce ${sport} risk or demand stronger edges.`
      );
    }
    if (s.roi >= 10 && s.n >= 4) {
      model.recommendations.push(
        `**${sport}** hot (${s.w}-${s.l}, +${s.roi.toFixed(1)}% ROI) — still size by process, slight priority OK.`
      );
    }
  }

  for (const [bandName, s] of Object.entries(model.byOddsBand)) {
    if (s.n < 3) continue;
    if (s.roi < -15) {
      model.recommendations.push(
        `Odds band **${bandName}** bleeding (${s.roi.toFixed(1)}% ROI) — fade that price zone.`
      );
    }
  }

  const topLoss = Object.entries(model.reasonLoss).sort((a, b) => b[1] - a[1])[0];
  if (topLoss && topLoss[1] >= 2) {
    model.recommendations.push(
      `Reason most tied to losses: **${topLoss[0]}** (x${topLoss[1]}) — discount this factor going forward.`
    );
  }
  const topWin = Object.entries(model.reasonWin).sort((a, b) => b[1] - a[1])[0];
  if (topWin && topWin[1] >= 2) {
    model.recommendations.push(
      `Reason most tied to wins: **${topWin[0]}** (x${topWin[1]}) — weight this higher on future cards.`
    );
  }

  if (!model.recommendations.length) {
    model.recommendations.push(
      "Not enough split sample yet — keep grading. Prediction weights unlock with history."
    );
  }

  return model;
}

/**
 * Score a prospective pick 0–100 using history (soft prior).
 * Used as guidance, not auto-lock.
 */
export function scoreProspect({ sport, label, betType, odds, reasons } = {}) {
  const model = buildModel();
  let score = 50;
  const notes = [];

  if (model.sample < 5) {
    return {
      score: 50,
      notes: ["Prior only — history thin; use film/process first"],
      model
    };
  }

  const sp = model.bySport[(sport || "").toUpperCase()];
  if (sp && sp.n >= 3) {
    if (sp.roi > 5) {
      score += 8;
      notes.push(`${sport} history +ROI`);
    }
    if (sp.roi < -10) {
      score -= 10;
      notes.push(`${sport} history cold`);
    }
  }

  const lab = model.byLabel[(label || "VALUE").toUpperCase()];
  if (lab && lab.n >= 3) {
    if (lab.roi > 0) score += 5;
    if (lab.roi < -10) {
      score -= 8;
      notes.push(`${label} tier underperforming`);
    }
  }

  const o = Number(odds);
  let band = "unknown";
  if (o <= -200) band = "big_fav";
  else if (o <= -140) band = "fav";
  else if (o < 0) band = "slight_fav";
  else if (o <= 140) band = "slight_dog";
  else if (o <= 200) band = "dog";
  else band = "longshot";
  const ob = model.byOddsBand[band];
  if (ob && ob.n >= 3) {
    if (ob.roi < -15) {
      score -= 12;
      notes.push(`${band} band has lost`);
    }
    if (ob.roi > 5) {
      score += 6;
      notes.push(`${band} band has paid`);
    }
  }

  const rs = Array.isArray(reasons)
    ? reasons
    : String(reasons || "")
        .split(/[|;\n]+/)
        .map((x) => x.trim().toLowerCase())
        .filter(Boolean);
  for (const r of rs) {
    if ((model.reasonLoss[r] || 0) >= 2) {
      score -= 5;
      notes.push(`loss-linked reason: ${r}`);
    }
    if ((model.reasonWin[r] || 0) >= 2) {
      score += 4;
      notes.push(`win-linked reason: ${r}`);
    }
  }

  score = Math.max(5, Math.min(95, score));
  return { score, notes, model };
}

export function learnEmbed() {
  const model = buildModel();
  const e = new EmbedBuilder()
    .setColor(config.colors?.gold || 0xc4a35a)
    .setTitle("🧠 LEARNING MODEL · FROM YOUR W/L")
    .setDescription(
      `Graded sample: **${model.sample}** · Overall ${model.overall.wins}–${model.overall.losses} · ` +
        `${model.overall.units >= 0 ? "+" : ""}${model.overall.units}u · ROI ${model.overall.roi}%\n` +
        (model.overall.usedSeed
          ? "_Day-1 seed still in play until legs are graded._\n"
          : "") +
        "\n**Forward guidance**\n" +
        model.recommendations.map((r) => `• ${r}`).join("\n")
    )
    .setFooter({
      text: "History shapes priors — film still required · 21+"
    })
    .setTimestamp();

  const sportLines = Object.entries(model.bySport)
    .filter(([, s]) => s.n >= 2)
    .map(
      ([k, s]) =>
        `**${k}** ${s.w}-${s.l} · ${s.units >= 0 ? "+" : ""}${s.units}u · ROI ${s.roi.toFixed(1)}%`
    );
  if (sportLines.length) {
    e.addFields({
      name: "By sport",
      value: sportLines.join("\n").slice(0, 1000),
      inline: false
    });
  }

  const labelLines = Object.entries(model.byLabel)
    .filter(([, s]) => s.n >= 2)
    .map(
      ([k, s]) =>
        `**${k}** ${s.w}-${s.l} · ROI ${s.roi.toFixed(1)}% (n=${s.n})`
    );
  if (labelLines.length) {
    e.addFields({
      name: "By label (LOCK must earn it)",
      value: labelLines.join("\n").slice(0, 1000),
      inline: false
    });
  }

  return e;
}

export function enhanceReviewEmbed() {
  const { insights, graded, summary } = analyzePatterns();
  const model = buildModel();
  const e = new EmbedBuilder()
    .setColor(0xc4a35a)
    .setTitle("🧠 SELF-REVIEW + PREDICTION PRIORS")
    .setDescription(
      `Graded: **${graded}** · ${summary.wins}–${summary.losses} · ${summary.units >= 0 ? "+" : ""}${summary.units}u\n\n` +
        insights
          .slice(0, 8)
          .map((i) => {
            const icon =
              i.level === "good" ? "✅" : i.level === "warn" ? "⚠️" : "ℹ️";
            return `${icon} ${i.text}`;
          })
          .join("\n\n") +
        "\n\n**What to do next**\n" +
        model.recommendations
          .slice(0, 6)
          .map((r) => `→ ${r}`)
          .join("\n")
    )
    .setFooter({ text: "EDGE PLAY · learn → tighter future cards · 21+" })
    .setTimestamp();
  return e;
}
