/**
 * EDGE PLAY PICS — live card + process desks
 * Updated: 2026-09-14 — real named picks (not empty templates only)
 */

export const limitsText = [
  "📐 **ph0** — no-vig when possible · +EV · LOCK must earn it",
  "📊 **Record** — /logpick → /grade → /review",
  "👑 **LOCK OF THE DAY** — one primary · **0.5–1u**",
  "🔒 **LOCK** — **0.5u** · clear process",
  "✅ **CAP** — **0.5u** · strong secondary",
  "💎 **VALUE** — **0.35–0.5u**",
  "➖ **LEAN** — **0.25u** · never spam",
  "🚫 **PASS** — no ticket",
  "📅 Day **5u** · AM **0.75u** · stop −4u / 3 losses",
  "📞 21+ · 1-800-GAMBLER"
].join("\n");

/** Auto / named exclusives — filled for today */
export const premiumAlerts = [
  {
    id: "wta-gdl-2026-09-14-dolehide",
    sport: "TENNIS",
    title: "Caroline Dolehide ML",
    market: "WTA Guadalajara · Zarazua vs Dolehide · ML",
    oddsBand: "Kalshi ~55¢ / about −120 to −130",
    why:
      "Form 7-4 last 11 hard vs Zarazua 1-5 last six hard. Serve/altitude/heat favor Dolehide. Zarazua weak set-2 (39%) and trail rate (15%). Kill case: TBs + home crowd (Zarazua 3-0 TB H2H).",
    size: "0.5u",
    media: "Process desk · not media chalk",
    expires: "match start ~4:10 PM ET",
    tier: "LOCK",
    selection: "Dolehide",
    opponent: "Zarazua",
    reasons: [
      "hard-court form",
      "serve hold edge",
      "altitude heat big-server",
      "Zarazua set-2 / comeback soft",
      "kill: tiebreaks + home altitude"
    ]
  }
];

/** Lock of the day — single primary */
export const lockOfTheDay = {
  date: "2026-09-14",
  sport: "TENNIS",
  event: "WTA Guadalajara",
  match: "Renata Zarazua vs Caroline Dolehide",
  pick: "Caroline Dolehide to win",
  market: "Match ML",
  priceGuide: "Kalshi ~55¢ · books ~−120 to −130",
  units: 0.5,
  tier: "LOCK OF THE DAY",
  analysis: {
    form:
      "Zarazua 1-5 last six on hard (lost from a set up to Iatcenko 160 and Tauson). Dolehide 7-4 last 11 on hard — Evansville title in stretch; losses tight (7-6 Parry, 7-6 Gorgodze, 3 sets Podrez).",
    serve:
      "Dolehide holds 74% ITF this year, 3.6% DF (10 matches). Zarazua 64% hold on hard last 52w, 2.2% DF (19). Dolehide tour sample 9.1% DF — small sample cuts both ways.",
    situational:
      "Zarazua wins set 2 only 39%, comes from behind 15% → Dolehide up a set is near done. Zarazua decides sets 73% → if three sets, do not add. Dolehide Guadalajara final 2023 as big server at altitude; ~3:30 local / heat = ball flies = her weather.",
    kill:
      "Tiebreaks + crowd. Zarazua 3-0 in TBs vs Dolehide; grew up 2,200m Mexico City. If DFs climb and sets hit breakers, H2H says Zarazua.",
    prediction: "Dolehide to win."
  },
  kalshi: "https://kalshi.com/tag/tennis — Zarazua vs Dolehide"
};

/** Today's multi-sport live card — pick every listed game; LOCK only when earned */
export const liveCard = {
  dateLabel: "MON SEP 14, 2026 · KALSHI + DESK CARD",
  updated: "2026-09-14T13:35:00-05:00",
  note: "Every game gets a ticket action: LOCK / VALUE / LEAN / HOLD / PASS. LOCK = clear process + stats, not hype.",
  picks: [
    {
      sport: "TENNIS",
      tier: "LOCK",
      game: "Zarazua vs Dolehide · WTA Guadalajara · ~4:10pm ET",
      selection: "Dolehide ML",
      price: "Kalshi ~55¢ / −120 to −130",
      units: 0.5,
      why: "Form 7-4 last 11 hard vs 1-5 hard stretch; serve + altitude heat; Zarazua set-2 39% / trail 15%. Kill: TBs + home.",
      type: "ml",
      player: "Caroline Dolehide",
      kalshi: true
    },
    {
      sport: "TENNIS",
      tier: "LEAN",
      game: "Stephens vs Monnet · WTA Guadalajara",
      selection: "Stephens ML",
      price: "Kalshi ~79¢ — only if ≤65¢ else PASS",
      units: 0.25,
      why: "Heavy chalk on Kalshi (~79%). Process likes Stephens but price is taxed — LEAN only on a better number.",
      type: "ml",
      player: "Sloane Stephens",
      kalshi: true
    },
    {
      sport: "TENNIS",
      tier: "LEAN",
      game: "Townsend vs Maria · WTA Guadalajara",
      selection: "Townsend ML",
      price: "Kalshi ~73¢ — prefer ≤62¢",
      units: 0.25,
      why: "Form side on paper; 73¢ is short for a LEAN max — PASS if no juice improvement.",
      type: "ml",
      player: "Taylor Townsend",
      kalshi: true
    },
    {
      sport: "TENNIS",
      tier: "HOLD",
      game: "Day vs Kalieva · WTA Guadalajara",
      selection: "Shop Day only in band",
      price: "Kalshi Day ~59¢",
      units: 0,
      why: "59¢ is playable-range but no full write-up edge stack — HOLD for price or skip.",
      type: "ml",
      player: "Kayla Day",
      kalshi: true
    },
    {
      sport: "NFL",
      tier: "LEAN",
      game: "DEN @ KC · MNF ~8:15pm ET",
      selection: "KC ML only if mid improves to ≤52¢",
      price: "Kalshi KC ~55¢",
      units: 0.25,
      why: "Division MNF. 55¢ soft fav is not LOCK. Injury/weather can flip — LEAN max or PASS.",
      type: "ml",
      player: null,
      kalshi: true
    },
    {
      sport: "MLB",
      tier: "HOLD",
      game: "LAD @ CIN",
      selection: "Wait SP confirm · no forced side",
      price: "Kalshi listed — shop 40–65¢",
      units: 0,
      why: "No lock without confirmed starter + mid. Public logos ≠ edge.",
      type: "ml",
      player: null,
      kalshi: true
    },
    {
      sport: "MLB",
      tier: "HOLD",
      game: "CWS @ CLE",
      selection: "CLE process only in 45–62¢ after SP",
      price: "band",
      units: 0,
      why: "Confirm arms. Chalk without SP = PASS.",
      type: "ml",
      player: null,
      kalshi: true
    },
    {
      sport: "MLB",
      tier: "HOLD",
      game: "NYY @ MIN / BAL @ NYM / ATL @ CHC",
      selection: "Board scan only — no blanket locks",
      price: "40–65¢ SP sides",
      units: 0,
      why: "Multiple games; each needs own SP + price. Desk does not invent 5 locks.",
      type: "ml",
      player: null,
      kalshi: true
    },
    {
      sport: "SOCCER",
      tier: "PASS",
      game: "EPL / live EU cards on Kalshi",
      selection: "Skip 1.15–1.30 badge chalk",
      price: "avoid short favs",
      units: 0,
      why: "Badge tax. Only 1.70–2.40 process sides with lineup news.",
      type: "ml",
      player: null,
      kalshi: true
    },
    {
      sport: "ESPORTS",
      tier: "PASS",
      game: "Kalshi esports boards",
      selection: "Liquidity filter first",
      price: "thin = PASS",
      units: 0,
      why: "No volume / no veto intel = no ticket.",
      type: "ml",
      player: null,
      kalshi: true
    }
  ],
  playerPicks: [
    {
      sport: "TENNIS",
      player: "Caroline Dolehide",
      market: "Match winner",
      side: "Yes / ML",
      tier: "LOCK",
      units: 0.5,
      note: "LOCK OF THE DAY — full /lotd write-up"
    },
    {
      sport: "TENNIS",
      player: "Sloane Stephens",
      market: "Match winner",
      side: "ML only ≤65¢",
      tier: "LEAN",
      units: 0.25,
      note: "Kalshi ~79¢ is too short for full size"
    },
    {
      sport: "NFL",
      player: "MNF props",
      market: "Player props",
      side: "PASS until role + number",
      tier: "PASS",
      units: 0,
      note: "No prop LOCK without usage + price"
    }
  ],
  hedges: [
    {
      related: "Dolehide ML",
      action: "HEDGE",
      when: "Zarazua takes set 1 OR DF spike / breakers",
      how: "0.25u max Zarazua live — not full reverse",
      units: 0.25
    },
    {
      related: "KC MNF lean",
      action: "HEDGE / CASH",
      when: "Down ≥10 in 2H or key injury",
      how: "Cash if offered · hedge ≤ original",
      units: 0.25
    }
  ],
  cashoutRules: [
    "Alert if tracked pick is live and margin looks bad (ESPN scan)",
    "Tennis: set down on ML process side → hedge check",
    "NFL: down 10+ in 2H on lean → cash/hedge",
    "Never chase full reverse after cashout"
  ],
  passBoard: [
    "Zarazua ML",
    "Stephens/Townsend at ≥70¢ chalk without better mid",
    "NFL 55¢+ with no injury edge",
    "MLB without SP confirmed",
    "Soccer 1.20 homes",
    "Esports thin books",
    "Any 'certain winner' with no stats stack"
  ],

  leanBoard: [
    {
      who: "Sloane Stephens",
      vs: "Monnet · WTA Guadalajara",
      action: "LEAN",
      onlyIf: "Kalshi/books ≤65¢ (now ~79¢ = too short)",
      units: 0.25,
      why: "Form side on paper but price is taxed. Lean is the player — only at a number."
    },
    {
      who: "Taylor Townsend",
      vs: "Maria · WTA Guadalajara",
      action: "LEAN",
      onlyIf: "≤62¢ (now ~73¢ = pass price)",
      units: 0.25,
      why: "Prefer Townsend process; do not lean into heavy chalk."
    },
    {
      who: "Kansas City Chiefs",
      vs: "DEN · MNF",
      action: "LEAN",
      onlyIf: "KC mid ≤52¢ (55¢ = soft, not forced)",
      units: 0.25,
      why: "Division MNF. Lean the logo only when the number is right — else sit."
    }
  ],
  holdBoard: [
    {
      who: "Kayla Day",
      vs: "Kalieva · Guadalajara",
      action: "HOLD",
      waitFor: "Price dip into mid-50s or sharper read",
      why: "~59¢ is the band but no full edge stack written — hold or skip."
    },
    {
      who: "LAD / CLE / NYY sides",
      vs: "MLB night slate",
      action: "HOLD",
      waitFor: "Confirmed SP + 40–65¢",
      why: "No arm listed = no ticket. Hold the board until starters lock."
    },
    {
      who: "Zarazua",
      vs: "Dolehide",
      action: "HOLD → actually PASS ML",
      waitFor: "Do not buy — only live if Dolehide collapses set 1 (hedge path)",
      why: "1-5 hard stretch; ML is the fade side for our LOTD."
    }
  ],
  mediaFollow: [
    {
      handle: "McBets-class / public touts",
      rule: "Log their pick → our size. Never auto-copy units.",
      map: "HOLD until price + confirmations"
    },
    {
      handle: "Kalshi timeline screenshots",
      rule: "Screenshot ≠ edge. Check mid + fees.",
      map: "LEAN max on lotto · never LOCK from a screenshot"
    },
    {
      handle: "Tennis media (GDL)",
      rule: "Home narrative on Zarazua — we faded ML with process.",
      map: "Media home ≠ our LOTD"
    },
    {
      handle: "NFL national TV",
      rule: "Prime-time sides often public.",
      map: "HOLD · shop number"
    },
    {
      handle: "MLB SP Twitter",
      rule: "Wait official lineup not quote-tweet.",
      map: "HOLD → LOCK only in band with SP"
    }
  ],
  kalshiSportsTracked: [
    "Tennis (WTA/ATP/Challenger)",
    "NFL (games, spreads, totals, futures)",
    "MLB / Pro Baseball",
    "NBA (when in season)",
    "Soccer / EPL / UCL",
    "NCAAF",
    "NHL / Hockey",
    "MMA / Boxing when listed",
    "Esports",
    "KBO / NPB when listed",
    "Olympics / specials when listed"
  ]
};

export const categories = {
  kbo: {
    key: "kbo",
    label: "KBO",
    emoji: "🌅",
    kalshi: "Baseball → Korea KBO",
    best: {
      title: "BEST TAKE · KBO",
      pick: "Next slate: SP confirmed · 45–62¢ only",
      odds: "45–62¢",
      size: "0.5u AM",
      why: "Overnight process — no SP = PASS"
    },
    locks: [],
    leans: [],
    pass: ["≥68¢ chalk", "No SP"],
    mediaOverall: "Media chalk on big clubs — fade tax",
    mediaBets: [
      { source: "KBO media", bet: "Favorites vs soft", map: "HOLD if ≥65¢" }
    ]
  },
  tennis: {
    key: "tennis",
    label: "Tennis",
    emoji: "🎾",
    kalshi: "Tennis · WTA/ATP/Challenger",
    best: {
      title: "BEST TAKE · TENNIS",
      pick: "Dolehide ML vs Zarazua (Guadalajara)",
      odds: "~55¢ / −120–130",
      size: "0.5u",
      why: "Form + serve + altitude; see /lotd full write-up"
    },
    locks: [
      {
        tier: "LOCK OF THE DAY",
        pick: "Dolehide ML",
        odds: "~55¢ Kalshi",
        size: "0.5u",
        note: "Zarazua 1-5 hard stretch · Dolehide 7-4 hard · kill = TBs"
      }
    ],
    leans: ["If Dolehide up a set — do not live-add Zarazua"],
    pass: ["Zarazua ML", "Three-set chase adds"],
    mediaOverall: "Home crowd on Zarazua — price already ~45¢",
    mediaBets: [
      { source: "Kalshi WTA GDL", bet: "Dolehide ~55¢", map: "LOCK OF THE DAY" }
    ]
  },
  nfl: {
    key: "nfl",
    label: "NFL",
    emoji: "🏈",
    kalshi: "NFL game + futures",
    best: {
      title: "BEST TAKE · NFL",
      pick: "DEN @ KC — shop only, not forced",
      odds: "KC ~55¢ Kalshi",
      size: "0–0.25u",
      why: "MNF division — LEAN max if number improves"
    },
    locks: [],
    leans: ["KC ML only ≤52¢ equivalent"],
    pass: ["Blind 55¢+ without injury edge"],
    mediaOverall: "National TV narratives — square sides",
    mediaBets: [
      { source: "Kalshi MNF", bet: "KC ~55¢", map: "LEAN/HOLD not LOCK" }
    ]
  },
  mlb: {
    key: "mlb",
    label: "MLB",
    emoji: "⚾",
    kalshi: "MLB when listed",
    best: {
      title: "BEST TAKE · MLB",
      pick: "SP confirmed sides in 40–65¢ only",
      odds: "−130 to +150",
      size: "0.5u",
      why: "No logo locks on night slate"
    },
    locks: [],
    leans: ["RL only if ML taxed"],
    pass: ["80% public", "−200 rainy chalk"],
    mediaOverall: "Public SP stars",
    mediaBets: [{ source: "MLB media", bet: "Ace chalk", map: "PASS if taxed" }]
  },
  nba: {
    key: "nba",
    label: "NBA",
    emoji: "🏀",
    kalshi: "NBA when listed",
    best: {
      title: "BEST TAKE · NBA",
      pick: "Offseason / futures only — no live LOCK card",
      odds: "—",
      size: "0u",
      why: "Wait regular season roles"
    },
    locks: [],
    leans: [],
    pass: ["Random futures as locks"],
    mediaOverall: "Star narratives",
    mediaBets: []
  },
  soccer: {
    key: "soccer",
    label: "Soccer",
    emoji: "⚽",
    kalshi: "Soccer / football",
    best: {
      title: "BEST TAKE · SOCCER",
      pick: "1.70–2.40 process — skip 1.15 badges",
      odds: "1.70–2.40",
      size: "0.5u",
      why: "Badge tax kills edge"
    },
    locks: [],
    leans: ["DNB when ML messy"],
    pass: ["1.15–1.30 chalk"],
    mediaOverall: "Big badges & homes",
    mediaBets: [{ source: "Soccer media", bet: "Home fav", map: "PASS if taxed" }]
  },
  mma: {
    key: "mma",
    label: "MMA / UFC",
    emoji: "🥋",
    kalshi: "MMA cards",
    best: {
      title: "BEST TAKE · MMA",
      pick: "Wait settled lines — no blind −300",
      odds: "playable only",
      size: "0.5u max",
      why: "Twitter heat ≠ LOCK"
    },
    locks: [],
    leans: [],
    pass: ["Open-week steam"],
    mediaOverall: "Star power",
    mediaBets: []
  },
  boxing: {
    key: "boxing",
    label: "Boxing",
    emoji: "🥊",
    kalshi: "Boxing",
    best: {
      title: "BEST TAKE · BOXING",
      pick: "Most cards PASS",
      odds: "rare",
      size: "0u",
      why: "Narrative market"
    },
    locks: [],
    leans: [],
    pass: ["Star ML chalk"],
    mediaOverall: "Star scripts",
    mediaBets: []
  },
  npb: {
    key: "npb",
    label: "NPB (Japan)",
    emoji: "🏯",
    kalshi: "Japan / NPB",
    best: {
      title: "BEST TAKE · NPB",
      pick: "SP + mid same as KBO",
      odds: "45–62¢",
      size: "0.5u",
      why: "Thin US media"
    },
    locks: [],
    leans: [],
    pass: ["No SP"],
    mediaOverall: "Light coverage",
    mediaBets: []
  },
  esports: {
    key: "esports",
    label: "Esports",
    emoji: "🎮",
    kalshi: "Esports",
    best: {
      title: "BEST TAKE · ESPORTS",
      pick: "Volume + intel only",
      odds: "tight",
      size: "0.25–0.5u",
      why: "Thin books die"
    },
    locks: [],
    leans: [],
    pass: ["No volume"],
    mediaOverall: "Fragmented",
    mediaBets: []
  },
  kalshi: {
    key: "kalshi",
    label: "Kalshi wide",
    emoji: "📡",
    kalshi: "All categories",
    best: {
      title: "BEST TAKE · KALSHI",
      pick: "Dolehide ~55¢ is today's best processed mid",
      odds: "fee-aware",
      size: "0.5u on LOTD",
      why: "Net after fees · liquid tennis match"
    },
    locks: [
      {
        tier: "LOCK OF THE DAY",
        pick: "Dolehide ML ~55¢",
        odds: "55¢",
        size: "0.5u",
        note: "Copy on Kalshi app · Zarazua vs Dolehide"
      }
    ],
    leans: ["KC MNF only if mid improves"],
    pass: ["≥88¢ chalk", "lottery parlays as locks"],
    mediaOverall: "Screenshots overstate edges",
    mediaBets: [
      { source: "Kalshi tennis", bet: "Dolehide", map: "LOCK OF THE DAY" }
    ]
  }
};

export const wireBoard = {
  title: "👑 EDGE PLAY PICS · THE WIRE",
  description:
    "**Lock of the Day + live card below.**\n" +
    "`/lotd` full write-up · `/locks` TAKE list · `/live` full card · `/best` ranked\n" +
    "Kalshi + books · ph0 process · size yourself.",
  takes: [
    {
      name: "👑 LOCK OF THE DAY",
      value:
        "**Dolehide ML** vs Zarazua · WTA Guadalajara · **0.5u**\n" +
        "Kalshi ~55¢ · `/lotd` for form/serve/situational/kill"
    },
    {
      name: "➖ NFL LEAN",
      value: "KC MNF only if number improves — not a lock at ~55¢"
    },
    {
      name: "📡 MLB",
      value: "HOLD forced locks — SP + band only"
    }
  ],
  mediaLocks: [
    {
      source: "Process desk",
      pick: "Dolehide Guadalajara",
      tier: "LOCK OF THE DAY"
    }
  ],
  footer: "EDGE PLAY · named picks when process clears"
};

export const kboBoard = {
  dateLabel: categories.kbo.label,
  description: categories.kbo.best.why,
  rows: [
    {
      action: "HOLD",
      game: "Next KBO slate",
      side: "Wait SP",
      why: "0u until confirmed"
    }
  ],
  pitchers: ["SP must be live"],
  media: [categories.kbo.mediaOverall],
  mediaLocks: categories.kbo.mediaBets.map((m) => ({
    source: m.source,
    pick: m.bet,
    tier: m.map
  })),
  footer: "KBO"
};

export const tennisBoard = {
  title: "🎾 TENNIS · LIVE",
  description: categories.tennis.best.why,
  takes: [
    {
      name: "👑 LOCK OF THE DAY · Dolehide",
      value:
        "ML vs Zarazua · ~55¢ · 0.5u\nForm + serve + altitude · kill = TBs/home"
    }
  ],
  mediaLocks: categories.tennis.mediaBets.map((m) => ({
    source: m.source,
    pick: m.bet,
    tier: m.map
  })),
  footer: "Tennis"
};

export const mediaBySport = {
  title: "📡 MEDIA · ALL SPORTS",
  lines: Object.values(categories).map(
    (c) => `**${c.label}** — ${c.mediaOverall}`
  )
};

export const sportsDesk = {
  title: "ALL CATEGORIES",
  description: "Sport commands + /lotd + /live",
  sports: Object.values(categories).map((c) => ({
    sport: c.label,
    kalshi: c.kalshi,
    premiumBar: c.best.odds,
    mediaOverall: c.mediaOverall,
    action: c.best.pick
  }))
};
